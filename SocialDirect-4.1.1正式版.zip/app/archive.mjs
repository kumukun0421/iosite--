// 毎日1回(日本時間 午前2時)、Atlasの容量を確認する。
// 470MBを超えていたら、1年より前のデータを古い順にR2へ移し、300MBになるまで続ける。
// 移す順番: R2へ保存 → 成功したらAtlasから削除。保存に失敗したら削除しないので、データは消えない。
import * as db from "./lib/db.mjs";
import * as r2 from "./lib/r2.mjs";

const MB = 1024 * 1024;
// Atlas(M0・512MB)の基準。D1 は上限が500MBで、容量の数え方も少し違うため、別の基準にする
const ATLAS = { START: 470 * MB, TARGET: 300 * MB };
const D1 = { START: 380 * MB, TARGET: 250 * MB };
const AGE_MS = 365 * 24 * 60 * 60 * 1000;
const mb = (n) => Math.round((n / MB) * 10) / 10;


export async function runArchive() {
  if (!r2.configured()) return { skipped: true, reason: "R2の設定がありません" };
  const kv = await db.kvDriver();
  const { START, TARGET } = kv.kind === "d1" ? D1 : ATLAS;
  let size = await kv.size();
  const before = size;
  if (size < START) return { skipped: true, sizeMB: mb(size) };

  const cutoff = Date.now() - AGE_MS;
  let moved = 0;
  for (let round = 0; size > TARGET && round < 500; round++) {
    const batch = await kv.oldest(cutoff, 200);
    if (!batch.length) break;
    for (const it of batch) {
      await r2.put(`archive/${it.key}`, Buffer.from(JSON.stringify({ data: it.data }), "utf8"), "application/json");
      await kv.del(it.key);
      moved++;
    }
    size = await kv.size();
  }
  return {
    beforeMB: mb(before),
    afterMB: mb(size),
    moved,
    // 1年より前のデータを全部移しても目標に届かない場合
    stillAboveTarget: size > TARGET,
  };
}

// 日本時間 午前2時以降で、今日まだ実行していなければ実行する。
// 「今日実行したか」はDBに保存するので、再起動しても二重に動かず、停止していた日も次の確認で動く。
export async function archiveIfDue() {
  const jst = new Date(Date.now() + 9 * 60 * 60 * 1000);
  const day = jst.toISOString().slice(0, 10);
  if (jst.getUTCHours() < 2) return null;
  if ((await db.getData("sys/archive-day")) === day) return null;
  let result;
  try {
    result = await runArchive();
  } catch (e) {
    result = { error: String(e && e.message || e) };
  }
  await db.put("sys/archive-day", day);
  return result;
}
