// SocialDirect API。/api/* を受け付ける(どのサーバーからも呼べる Request → Response の形)。
import { HttpError, authUser, authAdmin } from "./lib/core.mjs";
import { routes as userRoutes } from "./lib/routes.mjs";
import { routes as adminRoutes } from "./lib/admin.mjs";
import { allow, clientIp } from "./lib/limit.mjs";

const all = [...userRoutes, ...adminRoutes];

const json = (status, data) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" },
  });

export default async function handler(req) {
  const url = new URL(req.url);
  const path = url.pathname.replace(/^\/api/, "") || "/";
  try {
    for (const r of all) {
      if (r.method !== req.method) continue;
      const m = r.re.exec(path);
      if (!m) continue;
      const params = {};
      r.keys.forEach((k, i) => (params[k] = decodeURIComponent(m[i + 1])));
      // 回数制限: 同じ接続元からの連続した操作を止める(ログイン・登録・確認などは特に少なく)
      const ip = clientIp(req);
      const strict = { "/login": 30, "/register": 20, "/reset/verify": 30, "/admin/login": 10 }[path];
      if (strict && !allow(ip, "s" + path, strict)) return json(429, { error: "操作が多すぎます。少し待ってからもう一度お試しください" });
      if (path === "/check-name" && !allow(ip, "check", 120)) return json(429, { error: "操作が多すぎます。少し待ってからもう一度お試しください" });
      if (!allow(ip, "api", 600)) return json(429, { error: "操作が多すぎます。少し待ってからもう一度お試しください" });
      const ctx = { req, url, params, body: {}, user: null };
      if (r.admin) await authAdmin(req);
      if (r.auth) ctx.user = await authUser(req);
      if (req.method !== "GET" && req.method !== "HEAD") {
        const txt = await req.text();
        if (txt) {
          try {
            ctx.body = JSON.parse(txt);
          } catch {
            throw new HttpError(400, "リクエストの形式が正しくありません");
          }
        }
      }
      const out = await r.handler(ctx);
      if (out && out.raw) return out.raw;
      return json(200, out ?? { ok: true });
    }
    return json(404, { error: "見つかりません" });
  } catch (e) {
    if (e instanceof HttpError) return json(e.status, { error: e.message, ...e.extra });
    console.error(e);
    return json(500, { error: "サーバーでエラーが起きました。少し待ってからもう一度お試しください" });
  }
}

