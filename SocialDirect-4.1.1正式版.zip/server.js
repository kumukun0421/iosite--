// SocialDirect のサーバー(Node.js)。どのホスト(VPS・Render・Railway など)でも動く。
//   起動: npm install → npm start   (ポートは環境変数 PORT。省略時は 8888)
//   - public/ の画面を配信し、/api/* を app/api.mjs へ渡す
//   - 毎日1回(日本時間 午前2時)に、古いデータをR2へ移す(app/archive.mjs)
import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import handler from "./app/api.mjs";
import { archiveIfDue } from "./app/archive.mjs";
import * as db from "./app/lib/db.mjs";
import { normName, upgradeAllPasscodes } from "./app/lib/core.mjs";

// 開発用: SD_SQLITE_FILE を指定すると、D1 の代わりに SQLite のファイルを使う(本番では使わない)
if (process.env.SD_SQLITE_FILE) {
  const { makeD1 } = await import("./dev/d1-shim.mjs");
  globalThis.SD_D1 = makeD1(process.env.SD_SQLITE_FILE, path.join(path.dirname(fileURLToPath(import.meta.url)), "schema.sql"));
}

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.join(here, "public");
const port = Number(process.env.PORT) || 8888;
const MAX_BODY = 12 * 1024 * 1024; // 画像・動画の上限(5MB)より大きめに取る

const types = {
  ".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8", ".js": "text/javascript; charset=utf-8",
  ".svg": "image/svg+xml", ".png": "image/png", ".ico": "image/x-icon", ".webmanifest": "application/manifest+json",
};
// セキュリティの設定(どのホストでも同じように付ける)
const security = {
  "x-content-type-options": "nosniff",
  "referrer-policy": "same-origin",
  "x-frame-options": "DENY",
  "content-security-policy": "default-src 'self'; img-src 'self' data: blob: https://*.r2.cloudflarestorage.com; media-src 'self' blob: https://*.r2.cloudflarestorage.com; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'",
};

async function readBody(req) {
  const chunks = [];
  let size = 0;
  for await (const c of req) {
    size += c.length;
    if (size > MAX_BODY) throw Object.assign(new Error("too large"), { status: 413 });
    chunks.push(c);
  }
  return chunks.length ? Buffer.concat(chunks) : undefined;
}

// パスコード再設定の入力は、ユーザー名でも受け付ける。名前からユーザーIDを探して差し替えてから渡す
async function resetBody(buf) {
  try {
    const j = JSON.parse(buf.toString("utf8"));
    const input = String(j.id ?? "").trim();
    if (input) {
      const idx = await db.getData(`n/${encodeURIComponent(normName(input))}`);
      if (idx?.uid) return Buffer.from(JSON.stringify({ ...j, id: idx.uid }), "utf8");
    }
  } catch {}
  return buf;
}

async function api(req, res) {
  let body = ["GET", "HEAD"].includes(req.method) ? undefined : await readBody(req);
  if (body && req.method === "POST" && req.url === "/api/reset/verify") body = await resetBody(body);
  const r = await handler(new Request("http://localhost" + req.url, { method: req.method, headers: req.headers, body }));
  const headers = Object.fromEntries(r.headers);
  res.writeHead(r.status, { ...security, ...headers });
  res.end(Buffer.from(await r.arrayBuffer()));
}

function file(req, res) {
  let p = decodeURIComponent(req.url.split("?")[0]);
  if (p.endsWith("/")) p += "index.html";
  const f = path.join(root, p);
  if (!f.startsWith(root) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) {
    res.writeHead(404, security);
    return res.end("not found");
  }
  const cache = /^\/(js|css)\//.test(p) ? "no-cache" : "public, max-age=300";
  res.writeHead(200, { ...security, "content-type": types[path.extname(f)] || "application/octet-stream", "cache-control": cache });
  fs.createReadStream(f).pipe(res);
}

// 同時に処理する通信の上限(多すぎるときは、待たせずに「混み合っています」を返す)
const MAX_INFLIGHT = 80;
let inflight = 0;

http.createServer(async (req, res) => {
  if (inflight >= MAX_INFLIGHT) {
    res.writeHead(503, { ...security, "retry-after": "5", "content-type": "text/plain; charset=utf-8" });
    return res.end("混み合っています。少し待ってからもう一度お試しください");
  }
  inflight++;
  res.on("close", () => inflight--);
  req.setTimeout(30000);
  try {
    if (req.url === "/api" || req.url.startsWith("/api/") || req.url.startsWith("/api?")) return await api(req, res);
    file(req, res);
  } catch (e) {
    if (e.status === 413) { res.writeHead(413, security); return res.end("too large"); }
    console.error(e);
    res.writeHead(500, security);
    res.end("error");
  }
}).listen(port, () => console.log(`SocialDirect: http://localhost:${port}`));

// 起動のとき、以前の形式のパスコードを、復号できない形へ置き換える(何度実行しても安全)
upgradeAllPasscodes().then((n) => { if (n) console.log("passcodes upgraded", n); }).catch((e) => console.error("passcode upgrade failed", e));

// 5分ごとに「今日のアーカイブがまだか」を確かめる(日本時間 午前2時以降に1日1回だけ動く)
setInterval(async () => {
  try {
    const r = await archiveIfDue();
    if (r) console.log("archive", JSON.stringify(r));
  } catch (e) {
    console.error("archive check failed", e);
  }
}, 5 * 60 * 1000);
