-- SocialDirect のデータベース(Cloudflare D1)。最初に1回だけ実行する。
CREATE TABLE IF NOT EXISTS kv (
  k    TEXT PRIMARY KEY,
  d    TEXT NOT NULL,
  v    INTEGER NOT NULL DEFAULT 1,
  arch INTEGER NOT NULL DEFAULT 0,
  at   INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS kv_arch_at ON kv (arch, at);
