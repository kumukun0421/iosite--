// Direct(1対1・グループのやりとり)
(function () {
  const SD = window.SD;
  const h = SD.h;

  const chatName = (c) => {
    if (c.name) return c.name;
    const others = c.members.filter((m) => m.id !== SD.me.id);
    if (!c.group) return others[0]?.name || "自分";
    const names = others.map((m) => m.name);
    return names.slice(0, 3).join("、") + (names.length > 3 ? ` ほか${names.length - 3}人` : "");
  };
  const chatFace = (c, size) => {
    if (!c.group) return SD.avatar(c.members.find((m) => m.id !== SD.me.id) || SD.me, size);
    return h("span", { class: "av group", style: { width: size + "px", height: size + "px" } }, SD.icon("chat", Math.round(size * 0.5)));
  };

  // ---------- 一覧 ----------
  SD.route("/direct", async () => {
    if (!SD.need()) return;
    let data;
    try { data = await SD.get("/chats"); } catch (e) { return SD.fail(e); }
    SD.refreshUnread();
    const list = h("div", { class: "chat-list" },
      data.chats.length
        ? data.chats.map((c) =>
            h("a", { class: "chat-row", href: "#/direct/" + encodeURIComponent(c.id) },
              chatFace(c, 48),
              h("div", { class: "chat-mid" },
                h("div", { class: "chat-top" }, h("b", null, chatName(c)), c.last && h("span", { class: "time" }, SD.fmtTime(c.last.at))),
                h("p", { class: "chat-last" }, c.last ? (c.last.by === SD.me.name ? "自分: " : c.group ? c.last.by + ": " : "") + c.last.text : "まだメッセージはありません")),
              c.unread ? h("span", { class: "unread" }, String(c.unread)) : null))
        : h("div", { class: "empty-big" }, h("b", null, "まだやりとりがありません"), h("p", null, "右下のボタンから、相手を選んでメッセージを送ってみましょう。")));
    const fab = h("button", { class: "fab", onclick: () => SD.go("#/direct-new"), "aria-label": "新しいチャット" }, SD.icon("plus", 22), h("span", null, "新しいチャット"));
    SD.mount(SD.shell("Direct", list, { fab }));
    SD.onUnread && SD.onUnread();
  });

  // ---------- 新しいチャット ----------
  SD.route("/direct-new", async () => {
    if (!SD.need()) return;
    let info;
    try { info = await SD.get("/users"); } catch (e) { return SD.fail(e); }
    const users = info.users.filter((u) => u.id !== SD.me.id);
    let multi = false;
    const sel = { users: new Set(), tags: new Set() };
    const q = h("input", { type: "search", class: "input", placeholder: "名前で検索(一部だけでOK)", "aria-label": "検索" });
    const list = h("div", { class: "pick-list" });
    const chips = h("div", { class: "sel-chips" });
    const nameInput = h("input", { class: "input", maxLength: 30, placeholder: "グループ名(省略できます)", "aria-label": "グループ名" });
    const startBtn = h("button", { class: "btn primary block", onclick: start }, "チャットを始める");
    const bottom = h("div", { class: "multi-bar", hidden: true }, chips, nameInput, startBtn);
    const toggle = h("button", { class: "btn small", onclick: () => { multi = !multi; sel.users.clear(); sel.tags.clear(); draw(); } }, "選択");

    async function open(body) {
      try {
        const r = await SD.post("/chats", body);
        SD.go("#/direct/" + encodeURIComponent(r.chat.id));
      } catch (e) { SD.fail(e); }
    }
    function start() {
      if (!sel.users.size && !sel.tags.size) return SD.toast("相手を選んでください", { error: true });
      open({ userIds: [...sel.users], tagIds: [...sel.tags], name: nameInput.value });
    }
    function draw() {
      toggle.textContent = multi ? "選択をやめる" : "選択";
      toggle.classList.toggle("on", multi);
      const ts = info.tags.filter((t) => SD.match(q.value, t.name));
      const us = users.filter((u) => SD.match(q.value, u.name));
      const row = (set, id, content, onSingle) => {
        if (!multi) return h("button", { class: "pick-row btn-row", onclick: onSingle }, content);
        const cb = h("input", { type: "checkbox", checked: set.has(id), onchange: () => { cb.checked ? set.add(id) : set.delete(id); drawChips(); } });
        return h("label", { class: "pick-row" }, cb, content);
      };
      list.replaceChildren(...SD.kids(
        ts.length ? h("div", { class: "pick-sec" }, "タグ(みんなでグループチャット)") : null,
        ts.map((t) => row(sel.tags, t.id, [h("span", { class: "tag-chip" }, "#"), h("span", { class: "pick-name" }, t.name), h("span", { class: "pick-sub" }, `${t.members.length}人`)], () => open({ tagIds: [t.id], name: t.name }))),
        us.length ? h("div", { class: "pick-sec" }, "ユーザー") : null,
        us.map((u) => row(sel.users, u.id, [SD.avatar(u, 36), h("span", { class: "pick-name" }, u.name)], () => open({ userIds: [u.id] }))),
        !ts.length && !us.length ? h("p", { class: "empty" }, "見つかりませんでした") : null));
      bottom.hidden = !multi;
      drawChips();
    }
    function drawChips() {
      const n = sel.users.size + sel.tags.size;
      chips.replaceChildren(h("small", null, n ? `選択中: ${[...sel.tags].map((id) => "#" + info.tags.find((t) => t.id === id).name).concat([...sel.users].map((id) => users.find((u) => u.id === id).name)).join("、")}` : "人やタグを選んでください"));
      startBtn.disabled = !n;
    }
    q.addEventListener("input", draw);
    draw();
    SD.mount(SD.shell("新しいチャット", h("div", { class: "newchat" }, h("div", { class: "newchat-bar" }, q, toggle), list, bottom), { back: "#/direct" }));
  });

  // ---------- チャット画面 ----------
  SD.route("/direct/:id", async ({ id }) => {
    if (!SD.need()) return;
    let first;
    try { first = await SD.get(`/chats/${encodeURIComponent(id)}/messages`); } catch (e) { SD.fail(e); return SD.go("#/direct"); }
    const chat = first.chat;
    const box = h("div", { class: "msgs", "aria-live": "polite" });
    let last = "", lastDay = "";
    const seen = new Set();
    const nearBottom = () => box.scrollHeight - box.scrollTop - box.clientHeight < 160;
    const toBottom = () => { box.scrollTop = box.scrollHeight; };

    function reportMenu(m) {
      SD.modal({
        title: "メッセージの操作",
        body: h("div", null, h("p", { class: "quote" }, m.text.slice(0, 200)),
          h("button", { class: "choice", onclick: async () => {
            SD.closeAllModals();
            if (!(await SD.confirm("このメッセージを管理者に報告しますか?", "報告する", true))) return;
            try { await SD.post("/report", { chatId: id, msgId: m.id }); SD.toast("管理者に報告しました"); } catch (e) { SD.fail(e); }
          } }, SD.icon("flag", 22), h("div", null, h("b", null, "報告"), h("small", null, "管理者が内容を確認します")))),
      });
    }
    function editMsg(m, el) {
      const ta = h("textarea", { class: "input compose-text", rows: 5, maxLength: 2000, "aria-label": "メッセージ" });
      ta.value = m.text;
      SD.modal({
        title: "メッセージを編集", body: ta,
        actions: [
          { label: "キャンセル", ghost: true },
          {
            label: "保存する", primary: true,
            fn: async () => {
              const text = ta.value.trim();
              if (!text) { SD.toast("本文を入力してください", { error: true }); return false; }
              try {
                await SD.put(`/chats/${encodeURIComponent(id)}/messages/${encodeURIComponent(m.id)}`, { text });
                m.text = text;
                m.edited = true;
                el.querySelector(".bubble").textContent = text;
                if (!el.querySelector(".msg-edited")) el.querySelector(".msg-foot").prepend(h("small", { class: "msg-edited" }, "（編集済み）"));
              } catch (e) { SD.fail(e); return false; }
            },
          },
        ],
      });
    }
    async function deleteMsg(m, el) {
      if (!(await SD.confirm("このメッセージを削除します。元に戻せません。", "削除する", true))) return;
      try {
        await SD.del(`/chats/${encodeURIComponent(id)}/messages/${encodeURIComponent(m.id)}`);
        el.remove();
        SD.toast("削除しました");
      } catch (e) { SD.fail(e); }
    }
    function bubble(m) {
      const el = h("div", { class: "msg " + (m.mine ? "mine" : "other"), "data-id": m.id },
        !m.mine && SD.avatar(m.by, 34, { link: true }),
        h("div", { class: "msg-col" },
          !m.mine && chat.group && h("small", { class: "msg-name" }, m.by.name),
          h("div", { class: "bubble" }, m.text),
          h("div", { class: "msg-foot" },
            h("small", { class: "msg-time" }, SD.fmtTime(m.at)),
            m.edited && h("small", { class: "msg-edited" }, "（編集済み）"),
            !m.mine && h("button", { class: "msg-report", type: "button", onclick: () => reportMenu(m) }, SD.icon("flag", 13), "報告"),
            m.mine && h("button", { class: "msg-report", type: "button", onclick: () => editMsg(m, el) }, SD.icon("edit", 13), "編集"),
            m.mine && h("button", { class: "msg-report", type: "button", onclick: () => deleteMsg(m, el) }, SD.icon("trash", 13), "削除"))));
      if (!m.mine) {
        let t;
        const bub = el.querySelector(".bubble");
        const start = () => { t = setTimeout(() => reportMenu(m), 550); };
        const stop = () => clearTimeout(t);
        bub.addEventListener("pointerdown", start);
        ["pointerup", "pointerleave", "pointercancel", "pointermove"].forEach((ev) => bub.addEventListener(ev, stop));
        bub.addEventListener("contextmenu", (e) => { e.preventDefault(); stop(); reportMenu(m); });
      }
      return el;
    }
    function add(msgs) {
      for (const m of msgs) {
        if (seen.has(m.id)) continue;
        seen.add(m.id);
        const day = new Date(m.at).toLocaleDateString("ja-JP", { month: "long", day: "numeric", weekday: "short" });
        if (day !== lastDay) { box.append(h("div", { class: "day-sep" }, h("span", null, day))); lastDay = day; }
        box.append(bubble(m));
        last = m.id;
      }
    }
    add(first.messages);
    if (!first.messages.length) box.append(h("p", { class: "empty" }, "最初のメッセージを送ってみましょう"));
    SD.post(`/chats/${encodeURIComponent(id)}/read`).then((r) => { SD.unread = r.unread; SD.onUnread && SD.onUnread(); }).catch(() => {});

    const ta = h("textarea", { class: "input", rows: 1, maxLength: 2000, placeholder: "メッセージを入力", "aria-label": "メッセージ" });
    const sendBtn = h("button", { class: "btn primary icon-send", "aria-label": "送信" }, SD.icon("send", 20));
    ta.addEventListener("input", () => { ta.style.height = "auto"; ta.style.height = Math.min(ta.scrollHeight, 130) + "px"; });
    async function send() {
      const text = ta.value.trim();
      if (!text) return;
      sendBtn.disabled = true;
      try {
        const r = await SD.post(`/chats/${encodeURIComponent(id)}/messages`, { text });
        box.querySelector(".empty")?.remove();
        add([r.message]);
        ta.value = ""; ta.style.height = "auto";
        toBottom();
      } catch (e) { SD.fail(e); } finally { sendBtn.disabled = false; ta.focus(); }
    }
    sendBtn.addEventListener("click", send);
    ta.addEventListener("keydown", (e) => { if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) { e.preventDefault(); send(); } });

    const timer = setInterval(async () => {
      if (document.hidden) return;
      try {
        const stick = nearBottom();
        const r = await SD.get(`/chats/${encodeURIComponent(id)}/messages?after=${encodeURIComponent(last)}`, { quiet: false });
        if (r.messages.length) {
          box.querySelector(".empty")?.remove();
          add(r.messages);
          SD.post(`/chats/${encodeURIComponent(id)}/read`).catch(() => {});
          if (stick) toBottom();
        }
      } catch {}
    }, 10000);
    SD.onCleanup(() => clearInterval(timer));

    const title = chat.name || (chat.group ? chatName(chat) : chat.members.find((m) => m.id !== SD.me.id)?.name || "自分");
    const members = chat.group ? h("small", { class: "chat-members" }, chat.members.map((m) => m.name).join("、")) : null;
    SD.mount(SD.shell(title, h("div", { class: "chatpage" }, members, box, h("div", { class: "composer" }, ta, sendBtn)), { back: "#/direct", flush: true }));
    toBottom();
  });
})();
