// 管理者メニュー(SocialDirect全体の管理)
(function () {
  const SD = window.SD;
  const h = SD.h;

  const guard = () => {
    if (!SD.adminToken) { SD.go(SD.me ? "#/social" : "#/"); return false; }
    return true;
  };
  const page = (title, content, back = "#/admin") => SD.mount(SD.shell(title, content, { back, wide: true }));
  const homeBack = () => (SD.me ? "#/social" : "#/");
  const A = { get: SD.aget, post: SD.apost, put: SD.aput, del: SD.adel };
  const field = (label, input, hint) => h("label", { class: "field" }, h("span", { class: "field-label" }, label), input, hint || null);

  // 検索つきの単一選択リスト
  function selectList({ items, row, fields, onSelect, empty = "該当するものがありません" }) {
    const q = h("input", { type: "search", class: "input", placeholder: "部分検索", "aria-label": "検索" });
    const list = h("div", { class: "sel-list", role: "listbox" });
    let selected = null, view = items;
    const draw = () => {
      view = items.filter((it) => SD.match(q.value, ...fields(it)));
      list.replaceChildren(...(view.length ? view.map((it) => {
        const on = selected && selected.id === it.id;
        return h("button", { class: "sel-row" + (on ? " on" : ""), role: "option", "aria-selected": String(!!on), onclick: () => { selected = it; draw(); onSelect && onSelect(it); } }, row(it));
      }) : [h("p", { class: "empty" }, empty)]));
    };
    q.addEventListener("input", draw);
    draw();
    return { el: h("div", { class: "selectlist" }, q, list), get selected() { return selected; }, reset: () => { selected = null; draw(); } };
  }

  function orgSelect(orgs, onChange) {
    const sel = h("select", { class: "input", "aria-label": "組織", onchange: () => onChange(sel.value) },
      h("option", { value: "" }, "組織を選んでください"),
      orgs.map((o) => h("option", { value: o.id }, `${o.name}(${o.id})`)));
    return sel;
  }
  const userRow = (u) => [SD.avatar(u, 34), h("div", { class: "sel-main" }, h("b", null, u.name), h("small", null, `${u.orgName}(${u.org})`)), u.ban ? h("span", { class: "badge warn" }, "制限中") : null];

  // ---------- トップ ----------
  const tiles = [
    ["org-add", "組織の登録", "組織IDと名称を登録します", "plus"],
    ["org-del", "組織の削除", "組織と、その組織のアカウントを削除します", "trash"],
    ["user-del", "ユーザーの削除", "削除直後なら元に戻せます", "user"],
    ["reset", "パスコードのリセット", "本人確認をした人が、30分以内に再設定できるようにします", "shield"],
    ["posts", "投稿・お知らせの削除", "いいね・コメントごと消えます", "trash"],
    ["penalty", "ペナルティ", "指定した時間だけログインを止めます", "flag"],
    ["tag-add", "タグを追加", "組織を選んでタグを作ります", "plus"],
    ["tag-del", "タグを削除", "付いていた人からも外れます", "trash"],
    ["tag-edit", "タグを編集", "名前の変更、付与と剥奪", "edit"],
    ["cals", "SocialCalendar", "共有カレンダーの追加・編集・削除", "cal"],
    ["reports", "報告の確認", "Directで報告されたメッセージ", "flag"],
    ["notice", "お知らせを送る", "選んだ人が次にログインした時に届きます", "bell"],
    ["direct", "Direct", "全組織のDMを検索して、中身を見る・消す", "chat"],
  ];
  SD.route("/admin", async () => {
    if (!guard()) return;
    let pending = 0;
    try { pending = (await A.get("/admin/reports")).reports.filter((r) => !r.done).length; } catch {}
    SD.mount(SD.shell("管理者メニュー", h("div", { class: "admin-home" },
      h("p", { class: "hint" }, "どの組織・アカウントでログインしていても、SocialDirect全体を管理できます。"),
      h("div", { class: "tiles" }, tiles.map(([k, t, d, ic]) =>
        h("a", { class: "tile", href: "#/admin/" + k }, SD.icon(ic, 22), h("b", null, t, k === "reports" && pending ? h("span", { class: "nav-badge" }, String(pending)) : null), h("small", null, d)))),
      h("button", { class: "btn ghost", onclick: () => { SD.adminToken = null; SD.go(homeBack()); } }, "管理者メニューを閉じる")), { back: homeBack() }));
  });

  const sections = {};

  // ---------- 組織の登録 ----------
  sections["org-add"] = async () => {
    const id = h("input", { class: "input", maxLength: 32, autocomplete: "off", autocapitalize: "off", placeholder: "半角英小文字と数字だけ(例: school01)", "aria-label": "組織ID" });
    id.addEventListener("input", () => (id.value = id.value.toLowerCase().replace(/[^a-z0-9]/g, "")));
    const name = h("input", { class: "input", maxLength: 50, placeholder: "例: 第一高校", "aria-label": "組織の名称" });
    const err = h("p", { class: "form-err", role: "alert" });
    const listBox = h("div");
    const load = async () => {
      const r = await A.get("/admin/orgs");
      listBox.replaceChildren(h("h3", { class: "sec-title" }, `登録済みの組織(${r.orgs.length})`),
        r.orgs.length ? h("ul", { class: "plain-list" }, r.orgs.map((o) => h("li", null, h("b", null, o.name), h("code", null, o.id), h("small", null, `${o.users}人`)))) : h("p", { class: "empty" }, "まだ組織がありません"));
    };
    const btn = h("button", { class: "btn primary", onclick: async () => {
      err.textContent = "";
      btn.disabled = true;
      try { await A.post("/admin/orgs", { id: id.value, name: name.value }); SD.toast("組織を登録しました"); id.value = name.value = ""; await load(); } catch (e) { err.textContent = e.message; } finally { btn.disabled = false; }
    } }, "登録する");
    page("組織の登録", h("div", { class: "form" }, field("組織ID", id, h("small", { class: "hint" }, "ユーザーが登録するときに入力するIDです")), field("組織の名称", name), err, btn, listBox));
    await load();
  };

  // ---------- 組織の削除 ----------
  sections["org-del"] = async () => {
    const orgs = (await A.get("/admin/orgs")).orgs;
    const btn = h("button", { class: "btn danger", disabled: true, onclick: async () => {
      const o = list.selected;
      if (!(await SD.confirm(`「${o.name}(${o.id})」を削除します。この組織で登録されている${o.users}人のアカウントと、投稿・お知らせ・チャット・カレンダー・タグもすべて削除され、元に戻せません。`, "削除する", true))) return;
      try { await A.del("/admin/orgs/" + encodeURIComponent(o.id)); SD.toast("組織を削除しました"); sections["org-del"](); } catch (e) { SD.fail(e); }
    } }, "削除する");
    const list = selectList({ items: orgs, fields: (o) => [o.name, o.id], onSelect: () => (btn.disabled = false), row: (o) => [h("div", { class: "sel-main" }, h("b", null, o.name), h("small", null, `${o.id} ・ ${o.users}人`))] });
    page("組織の削除", h("div", null, h("p", { class: "hint" }, "削除する組織を選んでください。その組織のIDで登録されていたアカウントも自動的に削除されます。"), list.el, btn));
  };

  // ---------- ユーザーの削除 ----------
  sections["user-del"] = async (state = {}) => {
    const users = (await A.get("/admin/users")).users;
    const btn = h("button", { class: "btn danger", disabled: true, onclick: () => {
      const u = list.selected;
      const pw = h("input", { type: "password", class: "input", autocomplete: "off", placeholder: "管理者パスワード", "aria-label": "管理者パスワード", autofocus: true });
      const err = h("p", { class: "form-err", role: "alert" });
      pw.addEventListener("keydown", (e) => { if (e.key === "Enter") document.querySelector(".modal-foot .btn.danger")?.click(); });
      SD.modal({
        title: "ユーザーの削除", body: h("div", null, h("p", { class: "confirm-msg" }, `「${u.name}」(${u.orgName})を削除します。確認のため、管理者パスワードをもう一度入力してください。`), pw, err),
        actions: [{ label: "キャンセル", ghost: true }, {
          label: "削除する", danger: true,
          fn: async () => {
            try {
              await A.post(`/admin/users/${encodeURIComponent(u.id)}/delete`, { password: pw.value });
              SD.toast(`「${u.name}」を削除しました`, { action: { label: "元に戻す", fn: () => undo(u) }, ms: 15000 });
              sections["user-del"]({ undo: u });
            } catch (e) { err.textContent = e.message; pw.select(); return false; }
          },
        }],
      });
    } }, "削除する");
    async function undo(u) {
      try { await A.post(`/admin/users/${encodeURIComponent(u.id)}/undo`); SD.toast(`「${u.name}」を元に戻しました`); if (location.hash === "#/admin/user-del") sections["user-del"](); } catch (e) { SD.fail(e); }
    }
    const list = selectList({ items: users, fields: (u) => [u.name, u.org, u.orgName], onSelect: () => (btn.disabled = false), row: userRow });
    page("ユーザーの削除", h("div", null,
      state.undo ? h("div", { class: "undo-bar" }, h("span", null, `「${state.undo.name}」を削除しました。`), h("button", { class: "btn small", onclick: () => undo(state.undo) }, "元に戻す")) : null,
      h("p", { class: "hint" }, "削除すると、そのユーザー名は他の人が使えるようになります。削除直後だけ「元に戻す」で、まったく同じ状態に戻せます。"), list.el, btn));
  };

  // ---------- パスコードの確認 ----------
  // ---------- パスコードのリセット(本人確認をしたユーザーを選ぶ) ----------
  sections["reset"] = async () => {
    const users = (await A.get("/admin/users")).users;
    const out = h("div", { class: "pass-out" });
    let sel = null;
    // ボタンを押すだけで許可が下りる。IDを伝える必要はない(本人は自分のIDを入れる)
    const btn = h("button", { class: "btn primary", type: "button", disabled: true, onclick: async () => {
      try {
        const r = await A.post("/admin/reset-permit", { id: sel.id });
        out.replaceChildren(h("p", { class: "hint" }, `${r.name} さんの本人確認を完了しました。${r.expiresInMin}分以内に、本人が「パスコードをお忘れですか？」からパスコードを再設定できます。`));
        SD.toast("本人確認を完了しました");
      } catch (e) { SD.fail(e); }
    } }, "本人確認完了");
    const list = selectList({ items: users, fields: (u) => [u.name, u.org, u.orgName], row: userRow, onSelect: (u) => {
      sel = u; btn.disabled = false; out.replaceChildren();
    } });
    page("パスコードのリセット", h("div", null,
      h("p", { class: "hint" }, "本人から連絡があり、本人確認ができたら、ユーザーを選んで「本人確認完了」を押します。"),
      list.el, btn, out));
  };

  // ---------- お知らせを送る(選んだ人だけに。次のログイン時に届く) ----------
  sections["notice"] = async () => {
    const orgs = (await A.get("/admin/orgs")).orgs;
    const users = (await A.get("/admin/users")).users;
    const tagRows = [];
    for (const o of orgs) {
      for (const t of (await A.get("/admin/tags?org=" + encodeURIComponent(o.id))).tags) {
        tagRows.push({ org: o.id, orgName: o.name, id: t.id, name: t.name, n: t.members.length });
      }
    }
    const selOrg = new Set(), selTag = new Set(), selUser = new Set();
    const sumEl = h("small", { class: "hint" }, "");
    const sum = () => { sumEl.textContent = `選択中: 組織${selOrg.size}・タグ${selTag.size}・ユーザー${selUser.size}`; };
    const check = (set, k, label, sub) => h("label", { class: "pick-row" },
      h("input", { type: "checkbox", onchange: (e) => { e.target.checked ? set.add(k) : set.delete(k); sum(); } }),
      h("span", { class: "pick-name" }, label),
      sub ? h("span", { class: "pick-sub" }, sub) : null);
    sum();
    const orgBox = h("div", { class: "pick-list" }, orgs.length ? orgs.map((o) => check(selOrg, o.id, o.name, o.id)) : h("p", { class: "hint" }, "組織がまだありません"));
    const tagBox = h("div", { class: "pick-list" }, tagRows.length ? tagRows.map((t) => check(selTag, t.org + "|" + t.id, "#" + t.name, `${t.orgName} ・ ${t.n}人`)) : h("p", { class: "hint" }, "タグがまだありません"));
    const uq = h("input", { type: "search", class: "input", placeholder: "名前で部分検索(全組織)", "aria-label": "ユーザー検索" });
    const userBox = h("div", { class: "pick-list" });
    const drawUsers = () => userBox.replaceChildren(...users
      .filter((u) => SD.match(uq.value, u.name, u.org, u.orgName))
      .map((u) => check(selUser, u.id, u.name, u.orgName)));
    uq.addEventListener("input", SD.debounce(drawUsers, 150));
    drawUsers();

    const ta = h("textarea", { class: "input compose-text", rows: 6, maxLength: 5000, placeholder: "お知らせの内容", "aria-label": "お知らせの本文" });
    const cnt = h("small", { class: "counter" }, "0 / 5000");
    const prev = h("div", { class: "notice-preview" });
    const redraw = () => { cnt.textContent = `${ta.value.length} / 5000`; prev.replaceChildren(...SD.richText(ta.value)); };
    ta.addEventListener("input", redraw);
    const wrap = (open, close) => {
      const a = ta.selectionStart, b = ta.selectionEnd, v = ta.value;
      const mid = v.slice(a, b) || "文字";
      ta.value = v.slice(0, a) + open + mid + close + v.slice(b);
      ta.focus();
      ta.setSelectionRange(a + open.length, a + open.length + mid.length);
      redraw();
    };
    const tools = h("div", { class: "rt-tools" },
      h("button", { class: "btn small", type: "button", onclick: () => wrap("**", "**") }, h("b", null, "太字")),
      h("button", { class: "btn small", type: "button", onclick: () => wrap("__", "__") }, h("u", null, "下線")));

    const send = h("button", { class: "btn primary", type: "button", onclick: async () => {
      const text = ta.value.trim();
      if (!text) return SD.toast("本文を入力してください", { error: true });
      const toOrgs = [...selOrg];
      const toTags = [...selTag].map((k) => { const [org, id] = k.split("|"); return { org, id }; });
      const toUsers = [...selUser];
      if (!toOrgs.length && !toTags.length && !toUsers.length) return SD.toast("宛先を1つ以上選んでください", { error: true });
      if (!(await SD.confirm("このお知らせを送ります。宛先の人が次にログインした時に届きます。", "送信する", false))) return;
      try {
        const r = await A.post("/admin/notices", { text, toOrgs, toTags, toUsers });
        SD.toast(`${r.notice.count}人に送りました`);
        sections["notice"]();
      } catch (e) { SD.fail(e); }
    } }, "お知らせを送る");

    const sent = (await A.get("/admin/notices")).notices;
    const sentBox = h("div", { class: "sel-list" }, sent.length ? sent.map((n) =>
      h("div", { class: "sent-card" },
        h("small", null, `${SD.fmtTime(n.at)} ・ ${n.count}人に送信`),
        h("p", { class: "quote" }, ...SD.richText(n.text)),
        h("small", { class: "hint" }, n.labels.join("、")),
        h("div", { class: "row" }, h("button", { class: "btn small danger ghost", type: "button", onclick: async () => {
          if (!(await SD.confirm("このお知らせを削除します。まだ届いていない人には届かなくなります。", "削除する", true))) return;
          try { await A.post("/admin/notices/delete", { id: n.id }); sections["notice"](); } catch (e) { SD.fail(e); }
        } }, "削除する")))) : h("p", { class: "empty" }, "送ったお知らせはありません"));

    page("お知らせを送る", h("div", null,
      h("h3", { class: "sec-title" }, "宛先"),
      h("small", { class: "hint" }, "組織・タグ・ユーザーを、複数選べます。"),
      sumEl,
      h("h4", null, "組織"), orgBox,
      h("h4", null, "タグ"), tagBox,
      h("h4", null, "ユーザー"), uq, userBox,
      h("h3", { class: "sec-title" }, "本文"),
      tools, ta, h("div", null, cnt),
      h("div", null, h("small", { class: "hint" }, "プレビュー")), prev,
      h("div", { class: "row" }, send),
      h("h3", { class: "sec-title" }, "送ったお知らせ"),
      sentBox));
  };

  // ---------- 投稿・お知らせの削除 ----------
  sections["posts"] = async () => {
    const q = h("input", { type: "search", class: "input", placeholder: "本文・投稿者・組織で部分検索", "aria-label": "検索" });
    const box = h("div", { class: "sel-list" });
    let sel = null, posts = [];
    const btn = h("button", { class: "btn danger", disabled: true, onclick: async () => {
      if (!(await SD.confirm("この投稿を削除します。いいねとコメントも消え、誰にも見られなくなります。", "削除する", true))) return;
      try { await A.post("/admin/posts/delete", { id: sel.id }); SD.toast("削除しました"); sel = null; btn.disabled = true; await load(); } catch (e) { SD.fail(e); }
    } }, "削除する");
    const draw = () => box.replaceChildren(...(posts.length ? posts.map((p) =>
      h("button", { class: "sel-row post-row" + (sel?.id === p.id ? " on" : ""), onclick: () => { sel = p; btn.disabled = false; draw(); } },
        h("div", { class: "sel-main" },
          h("div", { class: "post-meta" }, h("span", { class: "badge" + (p.kind === "notice" ? "" : " mute") }, p.kind === "notice" ? "お知らせ" : "投稿"), h("b", null, p.by), h("small", null, `${p.orgName} ・ ${SD.fmtTime(p.at)}`)),
          h("p", { class: "snippet" }, p.text), h("small", null, `いいね ${p.likes} ・ コメント ${p.cc}`)))) : [h("p", { class: "empty" }, "該当する投稿はありません")]));
    const load = async () => { posts = (await A.get("/admin/posts?q=" + encodeURIComponent(q.value))).posts; draw(); };
    q.addEventListener("input", SD.debounce(load, 300));
    page("投稿・お知らせの削除", h("div", null, q, box, btn));
    await load();
  };

  // ---------- ペナルティ ----------
  sections["penalty"] = async () => {
    let users = (await A.get("/admin/users")).users;
    const day = h("input", { class: "input num", type: "number", min: 0, max: 365, value: 0, "aria-label": "日" });
    const hour = h("input", { class: "input num", type: "number", min: 0, max: 23, value: 0, "aria-label": "時間" });
    const min = h("input", { class: "input num", type: "number", min: 0, max: 59, value: 0, "aria-label": "分" });
    const reason = h("textarea", { class: "input", rows: 3, maxLength: 200, placeholder: "理由(本人にも表示されます)", "aria-label": "理由" });
    const info = h("p", { class: "hint" }, "ユーザーを選んでください");
    const run = h("button", { class: "btn danger", disabled: true, onclick: async () => {
      const total = (+day.value || 0) * 1440 + (+hour.value || 0) * 60 + (+min.value || 0);
      if (total < 1) return SD.toast("1分以上の時間を指定してください", { error: true });
      try { await A.post("/admin/penalty", { id: list.selected.id, minutes: total, reason: reason.value }); SD.toast("ペナルティを設定しました"); sections["penalty"](); } catch (e) { SD.fail(e); }
    } }, "ペナルティを実行");
    const lift = h("button", { class: "btn", hidden: true, onclick: async () => {
      try { await A.post("/admin/penalty", { id: list.selected.id, minutes: 0 }); SD.toast("制限を解除しました"); sections["penalty"](); } catch (e) { SD.fail(e); }
    } }, "制限を解除");
    const list = selectList({ items: users, fields: (u) => [u.name, u.org, u.orgName], row: userRow, onSelect: (u) => {
      run.disabled = false;
      lift.hidden = !u.ban;
      info.textContent = u.ban ? `「${u.name}」は ${new Date(u.ban.until).toLocaleString("ja-JP")} まで制限中です(理由: ${u.ban.reason})` : `「${u.name}」に設定します`;
    } });
    page("ペナルティ", h("div", { class: "form" }, list.el, info,
      h("div", { class: "dur" }, h("label", null, day, "日"), h("label", null, hour, "時間"), h("label", null, min, "分")),
      field("理由", reason), h("div", { class: "row" }, run, lift)));
  };

  // ---------- タグ ----------
  async function withOrg(titleText, hint, build) {
    const orgs = (await A.get("/admin/orgs")).orgs;
    const area = h("div", { class: "org-area" });
    const sel = orgSelect(orgs, async (id) => { area.replaceChildren(); if (id) await build(area, id); });
    page(titleText, h("div", { class: "form" }, hint ? h("p", { class: "hint" }, hint) : null, field("組織", sel), area));
  }

  sections["tag-add"] = () => withOrg("タグを追加", "まず組織を選びます。タグ名は、その組織の中で重複しないようにします。", async (area, org) => {
    const info = await A.get("/admin/org-users?org=" + encodeURIComponent(org));
    const name = h("input", { class: "input", maxLength: 30, placeholder: "タグの名前", "aria-label": "タグ名" });
    const pk = SD.picker({ users: info.users, tags: [] });
    const btn = h("button", { class: "btn primary", onclick: async () => {
      try { await A.post("/admin/tags", { org, name: name.value, members: pk.users }); SD.toast("タグを追加しました"); sections["tag-add"](); } catch (e) { SD.fail(e); }
    } }, "追加する");
    area.append(field("タグ名", name), h("h3", { class: "sec-title" }, "付ける人を選ぶ"), pk.el, btn);
  });

  sections["tag-del"] = () => withOrg("タグを削除", "組織を選んで、削除するタグを選びます。タグが外れるだけで、アカウントは消えません。", async (area, org) => {
    const tags = (await A.get("/admin/tags?org=" + encodeURIComponent(org))).tags;
    const btn = h("button", { class: "btn danger", disabled: true, onclick: async () => {
      const t = list.selected;
      if (!(await SD.confirm(`タグ「${t.name}」を削除します。付いていた${t.members.length}人からタグが外れます。`, "削除する", true))) return;
      try { await A.del("/admin/tags/" + encodeURIComponent(t.id)); SD.toast("タグを削除しました"); sections["tag-del"](); } catch (e) { SD.fail(e); }
    } }, "削除する");
    const list = selectList({ items: tags, fields: (t) => [t.name], onSelect: () => (btn.disabled = false), row: (t) => [h("span", { class: "tag-chip" }, "#"), h("div", { class: "sel-main" }, h("b", null, t.name), h("small", null, `${t.members.length}人`))], empty: "この組織にはタグがありません" });
    area.append(list.el, btn);
  });

  sections["tag-edit"] = () => withOrg("タグを編集", "組織とタグを選ぶと、名前の変更と、人への付与・剥奪ができます。", async (area, org) => {
    const info = await A.get("/admin/org-users?org=" + encodeURIComponent(org));
    const editor = h("div");
    const list = selectList({ items: info.tags, fields: (t) => [t.name], row: (t) => [h("span", { class: "tag-chip" }, "#"), h("div", { class: "sel-main" }, h("b", null, t.name), h("small", null, `${t.members.length}人`))], empty: "この組織にはタグがありません", onSelect: (t) => {
      const name = h("input", { class: "input", maxLength: 30, value: t.name, "aria-label": "タグ名" });
      const pk = SD.picker({ users: info.users, tags: [], selUsers: t.members });
      const btn = h("button", { class: "btn primary", onclick: async () => {
        try { await A.put("/admin/tags/" + encodeURIComponent(t.id), { name: name.value, members: pk.users }); SD.toast("タグを更新しました"); sections["tag-edit"](); } catch (e) { SD.fail(e); }
      } }, "保存する");
      editor.replaceChildren(h("h3", { class: "sec-title" }, `「${t.name}」を編集`), field("タグ名", name), h("p", { class: "hint" }, "チェックした人にタグが付きます。外すと剥奪されます。"), pk.el, btn);
    } });
    area.append(list.el, editor);
  });

  // ---------- SocialCalendar ----------
  sections["cals"] = () => withOrg("SocialCalendar", "組織を選ぶと、その組織の共有カレンダーを管理できます。", async (area, org) => {
    const info = await A.get("/admin/org-users?org=" + encodeURIComponent(org));
    const cals = (await A.get("/admin/cals?org=" + encodeURIComponent(org))).cals;
    const partText = (c) => `${c.users.length}人` + (c.tags.length ? ` ・ タグ${c.tags.length}件` : "");
    function form(cal) {
      const name = h("input", { class: "input", maxLength: 40, value: cal?.name || "", placeholder: "カレンダーの名前", "aria-label": "名前", autofocus: true });
      const pk = SD.picker({ users: info.users, tags: info.tags, selUsers: cal?.users || [], selTags: cal?.tags || [] });
      SD.modal({
        title: cal ? "共有カレンダーを編集" : "共有カレンダーを追加", wide: true,
        body: h("div", { class: "form" }, field("名前", name), h("h3", { class: "sec-title" }, "参加者(この人たちだけが見られます)"), pk.el),
        actions: [{ label: "キャンセル", ghost: true }, {
          label: "保存する", primary: true,
          fn: async () => {
            try {
              const payload = { name: name.value, users: pk.users, tags: pk.tags };
              if (cal) await A.put("/admin/cals/" + encodeURIComponent(cal.id), payload);
              else await A.post("/admin/cals", { ...payload, org });
              SD.toast("保存しました");
              sections["cals"]();
            } catch (e) { SD.fail(e); return false; }
          },
        }],
      });
    }
    area.append(
      h("div", { class: "row between" }, h("h3", { class: "sec-title" }, `共有カレンダー(${cals.length})`), h("button", { class: "btn small primary", onclick: () => form() }, SD.icon("plus", 16), "追加")),
      cals.length
        ? h("ul", { class: "plain-list" }, cals.map((c) => h("li", { class: "cal-admin" },
            h("div", { class: "sel-main" }, h("b", null, c.name), h("small", null, "参加: " + partText(c))),
            h("div", { class: "row" },
              h("button", { class: "btn small", onclick: () => form(c) }, "名前・参加者を編集"),
              h("button", { class: "btn small danger ghost", onclick: async () => {
                if (!(await SD.confirm(`共有カレンダー「${c.name}」を削除します。予定とコメントも完全に消え、参加者の画面からも表示されなくなります。`, "削除する", true))) return;
                try { await A.del("/admin/cals/" + encodeURIComponent(c.id)); SD.toast("削除しました"); sections["cals"](); } catch (e) { SD.fail(e); }
              } }, "削除")))))
        : h("p", { class: "empty" }, "共有カレンダーはまだありません"));
  });

  // ---------- Direct(全組織) ----------
  sections["direct"] = async () => {
    const q = h("input", { type: "search", class: "input", placeholder: "参加者の名前で部分検索(全組織)", "aria-label": "検索" });
    const box = h("div", { class: "sel-list" });
    let chats = [];
    const draw = () => box.replaceChildren(...(chats.length ? chats.map((c) =>
      h("button", { class: "sel-row post-row", onclick: () => openChat(c, load) },
        h("div", { class: "sel-main" },
          h("div", { class: "post-meta" }, h("span", { class: "badge" + (c.group ? "" : " mute") }, c.group ? "グループ" : "DM"), h("b", null, c.name || c.names.join("、")), h("small", null, c.orgName)),
          h("p", { class: "snippet" }, c.names.join("、")),
          h("small", null, c.lastAt ? `最終 ${SD.fmtTime(c.lastAt)} ・ ${c.lastText || "(メッセージなし)"}` : "まだメッセージはありません")))) : [h("p", { class: "empty" }, "該当するDMはありません")]));
    async function load() { chats = (await A.get("/admin/chats?q=" + encodeURIComponent(q.value))).chats; draw(); }
    q.addEventListener("input", SD.debounce(load, 300));
    page("Direct(全組織)", h("div", null, q, box));
    await load();
  };

  function openChat(c, onChanged) {
    const list = h("div", { class: "dm-msgs" });
    async function loadMsgs() {
      try {
        const r = await A.get(`/admin/chats/${encodeURIComponent(c.id)}/messages`);
        list.replaceChildren(...(r.messages.length ? r.messages.map((m) =>
          h("div", { class: "dm-msg" },
            h("div", { class: "post-meta" }, h("b", null, m.by), h("small", null, SD.fmtTime(m.at))),
            h("p", { class: "quote" }, m.text),
            h("button", { class: "btn small danger ghost", type: "button", onclick: async () => {
              if (!(await SD.confirm("このメッセージを削除します。", "削除する", true))) return;
              try { await A.post("/admin/chats/messages/delete", { chatId: c.id, msgId: m.id }); SD.toast("削除しました"); loadMsgs(); onChanged(); } catch (e) { SD.fail(e); }
            } }, "このメッセージを削除"))) : [h("p", { class: "empty" }, "メッセージはありません")]));
      } catch (e) { SD.fail(e); }
    }
    SD.modal({
      title: c.name || c.names.join("、"), wide: true, body: list,
      actions: [
        { label: "閉じる", ghost: true },
        {
          label: "このDMを全部削除", primary: true,
          fn: async () => {
            if (!(await SD.confirm("このDMのメッセージを全部削除します。元に戻せません。", "削除する", true))) return false;
            try { await A.post("/admin/chats/delete", { id: c.id }); SD.toast("DMを削除しました"); onChanged(); } catch (e) { SD.fail(e); return false; }
          },
        },
      ],
    });
    loadMsgs();
  }

  // ---------- 報告 ----------
  sections["reports"] = async () => {
    const reports = (await A.get("/admin/reports")).reports;
    const open = reports.filter((r) => !r.done), done = reports.filter((r) => r.done);
    const card = (r) =>
      h("li", { class: "report" + (r.done ? " done" : "") },
        h("div", { class: "post-meta" }, h("b", null, r.fromName), h("small", null, `${r.orgName} ・ 送信 ${SD.fmtTime(r.at)} ・ 報告者 ${r.reporterName}`)),
        h("p", { class: "quote" }, r.text),
        h("div", { class: "row" },
          !r.deleted && h("button", { class: "btn small danger ghost", onclick: async () => {
            if (!(await SD.confirm("このメッセージを削除します。", "削除する", true))) return;
            try { await A.post("/admin/messages/delete", { chatId: r.chatId, msgId: r.msgId }); SD.toast("メッセージを削除しました"); sections["reports"](); } catch (e) { SD.fail(e); }
          } }, "メッセージを削除"),
          h("button", { class: "btn small", onclick: async () => { try { await A.post(`/admin/reports/${encodeURIComponent(r.id)}/done`, { done: !r.done }); sections["reports"](); } catch (e) { SD.fail(e); } } }, r.done ? "未対応に戻す" : "対応済みにする")));
    page("報告の確認", h("div", null,
      h("h3", { class: "sec-title" }, `未対応(${open.length})`), open.length ? h("ul", { class: "plain-list" }, open.map(card)) : h("p", { class: "empty" }, "未対応の報告はありません"),
      done.length ? [h("h3", { class: "sec-title" }, `対応済み(${done.length})`), h("ul", { class: "plain-list" }, done.map(card))] : null));
  };

  SD.route("/admin/:sec", async ({ sec }) => {
    if (!guard()) return;
    if (!sections[sec]) return SD.go("#/admin");
    try { await sections[sec](); } catch (e) { SD.fail(e); }
  });
})();
