(function () {
  const SD = window.SD;
  const h = SD.h;

  // ---------- プロフィール(投稿のアイコンから開く) ----------
  SD.route("/user/:id", async ({ id }) => {
    if (!SD.need()) return;
    const uid = encodeURIComponent(id);
    let u;
    try { u = (await SD.get("/users/" + uid)).user; } catch (e) { SD.fail(e); return SD.go("#/social"); }

    const list = h("div", { class: "feed" });
    const sentinel = h("div", { class: "sentinel" });
    const endNote = h("p", { class: "feed-end", hidden: true }, "ここまでです");
    let next = null, loading = false, done = false, count = 0;
    async function more() {
      if (loading || done) return;
      loading = true;
      try {
        const r = await SD.get(`/users/${uid}/posts` + (next ? "?cursor=" + encodeURIComponent(next) : ""));
        r.items.forEach((p) => list.append(SD.postCard(p)));
        count += r.items.length;
        next = r.next;
        if (!next) {
          done = true;
          if (!count) list.append(h("div", { class: "empty-big" }, h("b", null, "まだ投稿がありません")));
          else endNote.hidden = false;
        }
      } catch (e) { SD.fail(e); } finally { loading = false; }
      if (!done && sentinel.getBoundingClientRect().top < window.innerHeight + 400) more();
    }
    const io = new IntersectionObserver((en) => en.some((e) => e.isIntersecting) && more(), { rootMargin: "500px" });
    SD.onCleanup(() => io.disconnect());

    const head = h("div", { class: "profile-head" },
      h("div", { class: "profile-av" }, SD.avatar(u, 96)),
      h("h2", { class: "profile-name" }, u.name),
      u.bio ? h("p", { class: "profile-bio" }, u.bio) : h("p", { class: "profile-bio muted" }, "自己紹介はまだありません"));

    SD.mount(SD.shell(u.name, h("div", null, head, h("h3", { class: "sec-title" }, "投稿"), list, sentinel, endNote), { back: "#/social" }));
    io.observe(sentinel);
    more();
  });
})();
