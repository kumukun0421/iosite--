// 通知(Web Push)の許可・端末の登録・通知の設定画面
(function () {
  const SD = window.SD;
  const h = SD.h;
  const DECLINED = "sd_notif_declined"; // 「今はしない」などで断った端末は、自動では聞かない
  const CATS = [
    ["invite", "Directに誘われたとき"],
    ["dm", "参加しているDirectでメッセージがあったとき"],
    ["calNew", "ソーシャルカレンダーに参加したとき"],
    ["calAct", "参加しているソーシャルカレンダーで、予定の追加・編集・削除やコメントがあったとき"],
    ["notice", "お知らせの宛先に入ったとき(ソーシャル・運営)"],
    ["comment", "自分の投稿にコメントがついたとき"],
    ["reply", "自分のコメントにコメントがついたとき"],
  ];

  // 許可を求めるのは Notification だけで足りる。Service Worker と Push は、登録のときに必要
  const hasNotif = () => "Notification" in window;
  const granted = () => hasNotif() && Notification.permission === "granted";
  const b64uBytes = (s) => {
    const pad = "=".repeat((4 - (s.length % 4)) % 4);
    const raw = atob((s + pad).replace(/-/g, "+").replace(/_/g, "/"));
    return Uint8Array.from(raw, (c) => c.charCodeAt(0));
  };
  const markDeclined = () => { try { localStorage.setItem(DECLINED, "1"); } catch {} };
  const isDeclined = () => { try { return localStorage.getItem(DECLINED) === "1"; } catch { return false; } };

  async function register() {
    if (!("serviceWorker" in navigator)) return null;
    try {
      const reg = await navigator.serviceWorker.register("/sw.js");
      if (!SD.swListening) {
        SD.swListening = true;
        // 通知を押したときは、その画面に移る
        navigator.serviceWorker.addEventListener("message", (e) => { if (e.data && e.data.type === "go" && e.data.hash) SD.go(e.data.hash); });
      }
      return reg;
    } catch { return null; }
  }

  // 許可済みの端末を、今ログインしている人の通知先として登録する
  SD.ensurePush = async function () {
    if (!granted() || !SD.me) return false;
    const reg = await register();
    if (!reg) return false;
    let sub = await reg.pushManager.getSubscription();
    if (!sub) {
      const { key } = await SD.get("/push/key");
      sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64uBytes(key) });
    }
    await SD.post("/push/subscribe", sub.toJSON(), { quiet: true });
    return true;
  };

  // この端末の通知先を外す(ログアウトのとき。次の人に前の人の通知が届かないように)
  SD.unsubscribePush = async function () {
    try {
      const reg = await navigator.serviceWorker?.getRegistration();
      const sub = await reg?.pushManager.getSubscription();
      if (sub) await SD.post("/push/unsubscribe", { endpoint: sub.endpoint }, { quiet: true });
    } catch {}
  };

  // ログイン・登録の後に一度だけ聞く。断った場合は、以後は自動では出さない
  SD.askNotify = function (then) {
    const done = () => then && then();
    if (!hasNotif() || Notification.permission !== "default" || isDeclined()) {
      SD.ensurePush().catch(() => {});
      return done();
    }
    SD.modal({
      title: "通知を受け取りますか？",
      body: h("div", null,
        h("p", null, "Directへの招待やメッセージ、ソーシャルカレンダーの変更などを、通知でお知らせできます。"),
        h("p", { class: "hint" }, "どの通知を受け取るかは、あとからメニューの「設定」で選べます。")),
      actions: [
        { label: "今はしない", ghost: true },
        { label: "通知を受け取る", primary: true, fn: async () => {
          const r = await Notification.requestPermission();
          if (r === "granted") { await SD.ensurePush().catch(() => {}); SD.toast("通知をオンにしました"); }
        } },
      ],
      // 閉じたとき、まだ許可も拒否もされていなければ「断った」として覚える
      onClose: () => { if (Notification.permission === "default") markDeclined(); done(); },
    });
  };

  const info = (title, text) => SD.modal({
    title, wide: true,
    body: h("div", null, ...text.map((t) => h("p", { class: "hint" }, t))),
    actions: [{ label: "閉じる", primary: true }],
  });
  const blockedInfo = () => info("通知がブロックされています", [
    "ブラウザで通知が止められているため、ここからは許可を求められません。",
    "アドレスバーの鍵マーク（または設定）から、このサイトの「通知」を「許可」に変えてください。変えたあとに、もう一度「設定」を開いてください。",
  ]);
  const statusText = () => {
    if (!hasNotif()) return "この端末では通知を使えません";
    return { granted: "許可されています", denied: "ブロックされています", default: "まだ許可されていません" }[Notification.permission];
  };

  // 設定を開く。未許可なら、もう一度申請する。許可されなければ開かない
  SD.openNotifySettings = async function () {
    if (!hasNotif()) return info("通知を使えません", ["この端末・ブラウザでは、通知の許可を求められません。iPhoneでは、ホーム画面に追加してから開くと使える場合があります。"]);
    if (Notification.permission === "denied") return blockedInfo();
    if (Notification.permission === "default") {
      try { await Notification.requestPermission(); } catch {}
    }
    if (Notification.permission === "denied") return blockedInfo();
    if (Notification.permission !== "granted") {
      return SD.toast("通知が許可されませんでした。もう一度「設定」を押すと、許可を求め直します", { error: true });
    }
    try { localStorage.removeItem(DECLINED); } catch {}
    await SD.ensurePush().catch(() => {});
    SD.go("#/settings/notify");
  };

  SD.route("/settings", () => {
    if (!SD.need()) return;
    const row = (label, fn) => h("button", { class: "settings-row", onclick: fn }, h("span", null, label), SD.icon("right", 18));
    SD.mount(SD.shell("設定", h("div", { class: "settings" },
      row("通知", () => SD.openNotifySettings()),
      h("p", { class: "hint" }, `この端末の通知: ${statusText()}`)), { back: "#/social" }));
  });

  SD.route("/settings/notify", async () => {
    if (!SD.need()) return;
    if (!granted()) {
      SD.toast("通知が許可されていないため、設定を開けません", { error: true });
      return SD.go("#/settings");
    }
    let notif;
    try { notif = (await SD.get("/me/notif")).notif; } catch (e) { return SD.fail(e); }
    const rows = CATS.map(([k, label]) => {
      const box = h("input", { type: "checkbox", checked: notif[k] !== false });
      box.addEventListener("change", async () => {
        try { notif = (await SD.post("/me/notif", { notif: { [k]: box.checked } })).notif; }
        catch (e) { box.checked = !box.checked; SD.fail(e); }
      });
      return h("label", { class: "notif-row" }, box, h("span", null, label));
    });
    SD.mount(SD.shell("通知", h("div", { class: "settings" },
      h("p", { class: "hint" }, "受け取る通知を選べます。オフにした通知は届きません。"),
      ...rows), { back: "#/settings" }));
  });

  // 起動したときに、許可済みの端末の登録を合わせる
  SD.registerPush = () => { if (SD.me) SD.ensurePush().catch(() => {}); };
})();
