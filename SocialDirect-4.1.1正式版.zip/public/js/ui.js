// SocialDirect 部品: アバター、選択リスト、トリミング、コメント、投稿カード
(function () {
  const SD = window.SD;
  const h = SD.h;
  const NS = "http://www.w3.org/2000/svg";

  // ---------- アバター(初期アイコン: 灰色の背景に濃いグレーの人型) ----------
  function defaultSvg() {
    const s = document.createElementNS(NS, "svg");
    s.setAttribute("viewBox", "0 0 40 40");
    s.setAttribute("aria-hidden", "true");
    const mk = (tag, attrs) => {
      const e = document.createElementNS(NS, tag);
      for (const [k, v] of Object.entries(attrs)) e.setAttribute(k, v);
      s.append(e);
    };
    mk("rect", { width: 40, height: 40, fill: "#d4d7dc" });
    mk("circle", { cx: 20, cy: 15.5, r: 6.6, fill: "#b4b9c1" });
    mk("path", { d: "M6.5 40c0-8.2 6-13.4 13.5-13.4S33.5 31.8 33.5 40z", fill: "#b4b9c1" });
    return s;
  }
  SD.avatar = function (u, size = 40, opt = {}) {
    const link = !!(opt.link && u && u.id && !u.gone);
    const el = h("span", {
      class: "av" + (link ? " av-link" : ""),
      style: { width: size + "px", height: size + "px" },
      ...(link ? {
        role: "link", tabindex: "0", "aria-label": `${u.name}のプロフィール`,
        onclick: (e) => { e.stopPropagation(); SD.go("#/user/" + encodeURIComponent(u.id)); },
        onkeydown: (e) => { if (e.key === "Enter") SD.go("#/user/" + encodeURIComponent(u.id)); },
      } : {}),
    });
    if (u && u.icon) el.append(h("img", { src: SD.mediaUrl(u.icon), alt: "", loading: "lazy", draggable: false }));
    else el.append(defaultSvg());
    return el;
  };

  // ---------- 検索つき選択リスト(人・タグ) ----------
  SD.picker = function ({ users, tags = [], selUsers = [], selTags = [], onChange, single = false }) {
    const su = new Set(selUsers), st = new Set(selTags);
    const q = h("input", { type: "search", class: "input", placeholder: "名前で検索(一部だけでOK)", "aria-label": "検索" });
    const count = h("div", { class: "pick-count" });
    const list = h("div", { class: "pick-list" });
    const upd = () => {
      count.textContent = `選択中: ${su.size}人` + (tags.length ? ` / タグ${st.size}件` : "");
      onChange && onChange({ users: [...su], tags: [...st] });
    };
    const row = (set, id, content) => {
      const cb = h("input", { type: "checkbox", checked: set.has(id), onchange: () => { cb.checked ? set.add(id) : set.delete(id); upd(); } });
      return h("label", { class: "pick-row" }, cb, content);
    };
    function draw() {
      const needle = q.value;
      const ts = tags.filter((t) => SD.match(needle, t.name));
      const us = users.filter((u) => SD.match(needle, u.name));
      list.replaceChildren(...SD.kids(
        ts.length ? h("div", { class: "pick-sec" }, "タグ") : null,
        ts.map((t) => row(st, t.id, [h("span", { class: "tag-chip" }, "#"), h("span", { class: "pick-name" }, t.name), h("span", { class: "pick-sub" }, `${t.members.length}人`)])),
        us.length ? h("div", { class: "pick-sec" }, "ユーザー") : null,
        us.map((u) => row(su, u.id, [SD.avatar(u, 32), h("span", { class: "pick-name" }, u.name)])),
        !ts.length && !us.length ? h("p", { class: "empty" }, "見つかりませんでした") : null
      ));
    }
    q.addEventListener("input", draw);
    draw();
    upd();
    return { el: h("div", { class: "picker" }, q, count, list), get users() { return [...su]; }, get tags() { return [...st]; } };
  };

  // ---------- 画像のトリミング(円形) ----------
  SD.cropper = async function (file, size = 280) {
    const bmp = await createImageBitmap(file);
    const c = h("canvas", { width: size, height: size, class: "crop-canvas" });
    const ctx = c.getContext("2d");
    const base = Math.max(size / bmp.width, size / bmp.height);
    let zoom = 1, ox = 0, oy = 0;
    const clamp = () => {
      const w = bmp.width * base * zoom, hh = bmp.height * base * zoom;
      ox = Math.min(Math.max(ox, -(w - size) / 2), (w - size) / 2);
      oy = Math.min(Math.max(oy, -(hh - size) / 2), (hh - size) / 2);
    };
    function paint(target, s, overlay) {
      const k = s / size;
      const g = target.getContext("2d");
      g.clearRect(0, 0, s, s);
      g.fillStyle = "#fff";
      g.fillRect(0, 0, s, s);
      const w = bmp.width * base * zoom * k, hh = bmp.height * base * zoom * k;
      g.drawImage(bmp, s / 2 - w / 2 + ox * k, s / 2 - hh / 2 + oy * k, w, hh);
      if (overlay) {
        g.save();
        g.fillStyle = "rgba(6,9,16,.72)";
        g.beginPath();
        g.rect(0, 0, s, s);
        g.arc(s / 2, s / 2, s / 2 - 3, 0, Math.PI * 2, true);
        g.fill("evenodd");
        g.strokeStyle = "rgba(255,255,255,.85)";
        g.lineWidth = 2;
        g.beginPath();
        g.arc(s / 2, s / 2, s / 2 - 3, 0, Math.PI * 2);
        g.stroke();
        g.restore();
      }
    }
    const draw = () => { clamp(); paint(c, size, true); };
    let drag = null;
    c.addEventListener("pointerdown", (e) => { drag = { x: e.clientX, y: e.clientY, ox, oy }; c.setPointerCapture(e.pointerId); });
    c.addEventListener("pointermove", (e) => {
      if (!drag) return;
      const r = c.getBoundingClientRect();
      const k = size / r.width;
      ox = drag.ox + (e.clientX - drag.x) * k;
      oy = drag.oy + (e.clientY - drag.y) * k;
      draw();
    });
    const end = () => (drag = null);
    c.addEventListener("pointerup", end);
    c.addEventListener("pointercancel", end);
    const slider = h("input", { type: "range", min: 1, max: 3, step: 0.01, value: 1, "aria-label": "拡大", class: "range", oninput: () => { zoom = +slider.value; draw(); } });
    draw();
    return {
      el: h("div", { class: "cropper" }, c, h("label", { class: "crop-zoom" }, h("span", null, "拡大"), slider), h("p", { class: "hint" }, "ドラッグで位置を調整できます。円の内側がアイコンになります。")),
      blob: () => {
        const o = document.createElement("canvas");
        o.width = o.height = 256;
        paint(o, 256, false);
        return new Promise((res) => o.toBlob(res, "image/jpeg", 0.9));
      },
    };
  };

  // 画像を選んでトリミングし、アップロードしてIDを返す。キャンセルなら null
  SD.pickIcon = function () {
    return new Promise((resolve) => {
      const input = h("input", { type: "file", accept: "image/*", hidden: true });
      document.body.append(input);
      input.addEventListener("change", async () => {
        const f = input.files[0];
        input.remove();
        if (!f) return resolve(null);
        if (!f.type.startsWith("image/")) { SD.toast("画像ファイルを選んでください", { error: true }); return resolve(null); }
        let cr;
        try { cr = await SD.cropper(f); } catch { SD.toast("この画像は読み込めませんでした", { error: true }); return resolve(null); }
        let done = false;
        SD.modal({
          title: "アイコンの切り取り",
          body: cr.el,
          actions: [
            { label: "キャンセル", ghost: true, fn: () => { done = true; resolve(null); } },
            {
              label: "この範囲にする", primary: true,
              fn: async () => {
                try {
                  const r = await SD.uploadBlob(await cr.blob(), "image/jpeg");
                  done = true;
                  resolve(r.id);
                } catch (e) { SD.fail(e); return false; }
              },
            },
          ],
          onClose: () => { if (!done) resolve(null); },
        });
      });
      input.click();
    });
  };

  // ---------- 添付メディア ----------
  SD.mediaView = function (media) {
    if (!media || !media.length) return null;
    return h("div", { class: "media-grid n" + Math.min(media.length, 4) },
      media.map((m) =>
        m.type === "video"
          ? h("video", { src: SD.mediaUrl(m.id), controls: true, preload: "metadata", playsinline: true })
          : h("img", { src: SD.mediaUrl(m.id), alt: "添付画像", loading: "lazy", onclick: () => SD.modal({ bare: true, body: h("img", { class: "lightbox", src: SD.mediaUrl(m.id), alt: "添付画像" }) }) })
      ));
  };

  // ---------- コメント(返信つき) ----------
  SD.comments = function ({ load, send, canComment = true }) {
    const list = h("div", { class: "cm-list" });
    const ta = h("textarea", { class: "input cm-input", rows: 1, maxLength: 1000, placeholder: "コメントを書く", "aria-label": "コメント" });
    const chip = h("div", { class: "reply-chip", hidden: true });
    let parent = null, all = [];
    const setParent = (c) => {
      parent = c ? c.id : null;
      chip.hidden = !c;
      chip.replaceChildren(...(c ? [h("span", null, `${c.by.name}さんに返信`), h("button", { class: "icon-btn", "aria-label": "返信をやめる", onclick: () => setParent(null) }, SD.icon("close", 16))] : []));
      if (c) ta.focus();
    };
    function node(c, depth, kids) {
      const mine = kids.get(c.id) || [];
      return h("div", { class: "cm", style: { marginLeft: Math.min(depth, 3) * 18 + "px" } },
        h("div", { class: "cm-main" },
          SD.avatar(c.by, 32, { link: true }),
          h("div", { class: "cm-body" },
            h("div", { class: "cm-head" }, h("b", null, c.by.name), h("span", { class: "time" }, SD.fmtTime(c.at))),
            h("p", { class: "text" }, c.text),
            canComment && h("button", { class: "link-btn", onclick: () => setParent(c) }, "返信"))),
        mine.map((k) => node(k, depth + 1, kids)));
    }
    function draw() {
      const kids = new Map();
      const roots = [];
      const ids = new Set(all.map((c) => c.id));
      for (const c of all) {
        if (c.parent && ids.has(c.parent)) kids.set(c.parent, [...(kids.get(c.parent) || []), c]);
        else roots.push(c);
      }
      list.replaceChildren(...(roots.length ? roots.map((c) => node(c, 0, kids)) : [h("p", { class: "empty" }, "まだコメントはありません")]));
    }
    async function refresh() {
      try { all = (await load()).comments.sort((a, b) => a.at - b.at); draw(); } catch (e) { SD.fail(e); }
    }
    const btn = h("button", {
      class: "btn primary small",
      onclick: async () => {
        const text = ta.value.trim();
        if (!text) return;
        btn.disabled = true;
        try {
          const r = await send(text, parent);
          all.push(r.comment);
          ta.value = "";
          setParent(null);
          draw();
        } catch (e) { SD.fail(e); } finally { btn.disabled = false; }
      },
    }, "送信");
    ta.addEventListener("input", () => { ta.style.height = "auto"; ta.style.height = Math.min(ta.scrollHeight, 140) + "px"; });
    const el = h("div", { class: "comments" }, list, canComment && h("div", { class: "cm-compose" }, chip, h("div", { class: "cm-row" }, ta, btn)));
    refresh();
    return { el, refresh, get count() { return all.length; } };
  };

  // ---------- 投稿カード ----------
  // ---------- 投稿の編集・削除(本人だけ) ----------
  SD.postMenu = function (p, { onEdited, onDeleted, detail = false }) {
    SD.modal({
      title: "投稿の操作",
      body: h("div", { class: "choices" },
        h("button", { class: "choice", onclick: () => { SD.closeAllModals(); editPost(p, onEdited); } },
          SD.icon("edit", 26), h("div", null, h("b", null, "編集"), h("small", null, "文章を書き直します"))),
        h("button", { class: "choice", onclick: async () => {
          SD.closeAllModals();
          if (!(await SD.confirm("この投稿を削除します。いいねとコメントも消えて、元に戻せません。", "削除する", true))) return;
          try {
            await SD.del(`/posts/${encodeURIComponent(p.id)}`);
            SD.toast("削除しました");
            onDeleted && onDeleted(detail);
          } catch (e) { SD.fail(e); }
        } },
          SD.icon("trash", 26), h("div", null, h("b", null, "削除"), h("small", null, "元に戻せません")))),
    });
  };
  function editPost(p, onEdited) {
    const ta = h("textarea", { class: "input compose-text", rows: 7, maxLength: 2000, "aria-label": "本文" });
    ta.value = p.text;
    SD.modal({
      title: "投稿を編集", body: ta, wide: true,
      actions: [
        { label: "キャンセル", ghost: true },
        {
          label: "保存する", primary: true,
          fn: async () => {
            const text = ta.value.trim();
            if (!text) { SD.toast("本文を入力してください", { error: true }); return false; }
            try {
              const r = await SD.put(`/posts/${encodeURIComponent(p.id)}`, { text });
              p.text = r.post.text;
              p.edited = true;
              onEdited && onEdited();
              SD.toast("保存しました");
            } catch (e) { SD.fail(e); return false; }
          },
        },
      ],
    });
  }

  // 「**太字**」「__下線__」を、安全にDOMへ変換する
  SD.richText = function (text) {
    const out = [];
    const re = /\*\*([^*]+)\*\*|__([^_]+)__/g;
    let last = 0, m;
    while ((m = re.exec(text)) !== null) {
      if (m.index > last) out.push(text.slice(last, m.index));
      out.push(m[1] !== undefined ? h("strong", null, m[1]) : h("u", null, m[2]));
      last = re.lastIndex;
    }
    if (last < text.length) out.push(text.slice(last));
    return out;
  };

  SD.postCard = function (p, { detail = false } = {}) {
    const likeBtn = h("button", { class: "act like" + (p.liked ? " on" : ""), "aria-pressed": String(!!p.liked), "aria-label": "いいね" });
    const likeNum = h("span", null, String(p.likes));
    const paintLike = () => {
      likeBtn.classList.toggle("on", p.liked);
      likeBtn.setAttribute("aria-pressed", String(p.liked));
      likeNum.textContent = String(p.likes);
    };
    likeBtn.append(SD.svg(SD.icons.good, { size: 20, fill: false }), likeNum);
    likeBtn.addEventListener("click", async (e) => {
      e.stopPropagation();
      p.liked = !p.liked;
      p.likes += p.liked ? 1 : -1;
      paintLike();
      try {
        const r = await SD.post(`/posts/${encodeURIComponent(p.id)}/like`);
        p.liked = r.liked;
        p.likes = r.count;
        paintLike();
      } catch (err) {
        p.liked = !p.liked;
        p.likes += p.liked ? 1 : -1;
        paintLike();
        SD.fail(err);
      }
    });
    const cmBtn = h("button", { class: "act", "aria-label": "コメント", onclick: (e) => { e.stopPropagation(); if (!detail) SD.go("#/post/" + encodeURIComponent(p.id)); } },
      SD.icon("comment", 20), h("span", { class: "cm-num" }, String(p.cc)));
    const isNotice = p.kind === "notice";
    const toLine = isNotice
      ? h("p", { class: "to-line" }, "宛先: ", p.to.join("、") + (p.toCount > p.to.length ? ` ほか${p.toCount - p.to.length}人` : ""))
      : null;
    const textEl = h("p", { class: "text" }, p.text);
    const edLabel = h("small", { class: "edited", hidden: !p.edited }, "（編集済み）");
    const canEdit = p.mine && !isNotice;
    const menuBtn = canEdit
      ? h("button", { class: "post-menu", type: "button", "aria-label": "投稿の操作", onclick: (e) => {
          e.stopPropagation();
          SD.postMenu(p, {
            detail,
            onEdited: () => { textEl.textContent = p.text; edLabel.hidden = false; },
            onDeleted: (isDetail) => (isDetail ? SD.go("#/social") : el.remove()),
          });
        } }, "⋯")
      : null;
    const el = h("article", { class: "post" + (isNotice ? " notice" : "") },
      SD.avatar(p.by, 44, { link: true }),
      h("div", { class: "post-main" },
        h("div", { class: "post-head" },
          h("b", { class: "name" }, p.by.name),
          isNotice && h("span", { class: "badge" }, "お知らせ"),
          h("span", { class: "time" }, SD.fmtTime(p.at)),
          edLabel,
          menuBtn),
        toLine,
        textEl,
        SD.mediaView(p.media),
        h("div", { class: "post-acts" }, likeBtn, cmBtn)));
    return el;
  };
})();
