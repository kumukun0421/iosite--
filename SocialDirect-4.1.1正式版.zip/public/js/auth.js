// ホーム、ユーザー登録、ログイン、プロフィール編集
(function () {
  const SD = window.SD;
  const h = SD.h;

  SD.need = () => {
    if (SD.me) return true;
    SD.go("#/auth");
    return false;
  };

  // ---------- ホーム ----------
  const arrow = () => {
    const ns = "http://www.w3.org/2000/svg";
    const s = document.createElementNS(ns, "svg");
    s.setAttribute("viewBox", "0 0 120 120");
    s.setAttribute("class", "wm-arrow");
    s.setAttribute("aria-hidden", "true");
    const p = document.createElementNS(ns, "path");
    p.setAttribute("d", "M12 12 L100 100 M100 100 L100 46 M100 100 L46 100");
    p.setAttribute("fill", "none");
    p.setAttribute("stroke", "currentColor");
    p.setAttribute("stroke-width", "7");
    p.setAttribute("stroke-linecap", "square");
    s.append(p);
    return s;
  };

  SD.route("/", () => {
    if (SD.me) return SD.go("#/social");
    const features = [
      ["お知らせ", "宛先を選んで、必要な人にだけ届けます。20000字まで書けて、画像や動画も付けられます。"],
      ["つぶやき", "日々のひとことを、同じ組織のみんなと。いいねとコメントで気軽に反応できます。"],
      ["Direct", "名前やタグから相手を選んで、1対1でもグループでもやりとりできます。"],
      ["SocialCalendar", "自分だけの予定と、みんなで使う共有カレンダー。予定ごとにコメントもできます。"],
    ];
    SD.mount(
      h("div", { class: "home" },
        h("header", { class: "home-top" },
          h("span", { class: "logo", "aria-label": "SocialDirect" }, SD.wordmarkSmall()),
          h("a", { class: "link-btn", href: "#/auth?login" }, "ログイン")),
        h("section", { class: "hero" },
          h("div", { class: "hero-grid", "aria-hidden": "true" }),
          h("h1", { class: "wordmark", "aria-label": "SocialDirect" },
            h("span", { class: "wm-a", "aria-hidden": "true" }, "Social"),
            h("span", { class: "wm-b", "aria-hidden": "true" }, "Direct"),
            arrow()),
          h("p", { class: "lead" }, "ioが開発した万能サイト"),
          h("p", { class: "lead-sub" }, "お知らせも、ひとことも、1対1のやりとりも、予定の共有も。ひとつの場所でまとめて使えます。"),
          h("a", { class: "btn primary large", href: "#/auth" }, "さっそく始める")),
        h("section", { class: "features", "aria-label": "特徴" },
          h("dl", null, features.map(([t, d]) => h("div", { class: "feat" }, h("dt", null, t), h("dd", null, d))))),
        h("section", { class: "updates", "aria-label": "アップデート情報" },
          h("h2", { class: "sec-title" }, "アップデート情報"),
          h("ul", { class: "upd-list" }, (SD.UPDATES || []).map((u) =>
            h("li", { class: "upd" },
              h("div", { class: "upd-head" }, h("span", { class: "upd-ver" }, "v" + u.version), h("time", null, u.date), h("b", null, u.title)),
              h("p", null, u.body))))),
        h("footer", { class: "home-foot" }, h("span", null, "© io  SocialDirect  "), h("button", { class: "link-btn", onclick: () => SD.adminGate() }, "管理者専用")))
    );
  });

// ---------- パスコードの再設定 ----------
  SD.route("/reset", () => {
    if (SD.me) return SD.go("#/social");
    const body = h("div", { class: "reset" });
    const err = h("p", { class: "form-err", role: "alert" });

    // 最初の画面で、管理者に確認してもらったIDを入れると、そのまま再設定画面へ進む
    function step1() {
      err.textContent = "";
      const id = h("input", { class: "input", autocomplete: "off", autocapitalize: "off", spellcheck: false, maxLength: 80, placeholder: "ご自分のユーザーID", "aria-label": "本人確認ID" });
      const go = async () => {
        err.textContent = "";
        const v = id.value.trim();
        if (!v) return (err.textContent = "IDを入力してください");
        try {
          const r = await SD.post("/reset/verify", { id: v }, { quiet: true });
          step3(r.token);
        } catch (e) {
          if (e.extra?.code === "contact") showContact();
          else err.textContent = e.message;
        }
      };
      id.addEventListener("input", () => { err.textContent = ""; });
      body.replaceChildren(
        h("form", { class: "form", onsubmit: (e) => { e.preventDefault(); go(); } },
          field("ユーザーID", id), err,
          h("button", { class: "btn primary block", type: "submit" }, "次へ")));
      setTimeout(() => id.focus(), 30);
    }

    // 本人確認の許可がないときの案内(ポップアップ)
    function showContact() {
      SD.modal({
        title: "本人確認が必要です",
        body: h("p", { class: "confirm-msg" }, "パスコードのリセットには本人確認が必要です。管理者に自分のユーザーIDと組織IDを伝え、「パスコードを再設定したい」旨お伝えください。ご連絡は「iori04210611@gmail.com」もしくは口頭でお伝えください。本人確認は30分間有効です。"),
        actions: [{ label: "閉じる", primary: true }],
      });
    }

    function step3(token) {
      err.textContent = "";
      const p1 = h("input", { class: "input pass", type: "password", inputMode: "numeric", autocomplete: "new-password", maxLength: 4, placeholder: "••••", "aria-label": "新しいパスコード" });
      const p2 = h("input", { class: "input pass", type: "password", inputMode: "numeric", autocomplete: "new-password", maxLength: 4, placeholder: "••••", "aria-label": "新しいパスコード(確認)" });
      digits(p1); digits(p2);
      const save = h("button", { class: "btn primary block", type: "button", onclick: async () => {
        err.textContent = "";
        if (!/^\d{4}$/.test(p1.value)) return (err.textContent = "パスコードは4桁の数字で入力してください");
        if (p1.value !== p2.value) return (err.textContent = "2回の入力が一致しません");
        try {
          await SD.post("/reset", { token, pass: p1.value }, { quiet: true });
          SD.toast("パスコードを再設定しました。ログインしてください");
          SD.go("#/auth?login");
        } catch (e) { err.textContent = e.message; }
      } }, "再設定する");
      body.replaceChildren(h("p", { class: "hint" }, "新しいパスコード(4桁の数字)を、2回入力してください。"),
        field("新しいパスコード", p1), field("もう一度入力", p2), err, save);
      setTimeout(() => p1.focus(), 30);
    }

    SD.mount(SD.shell("パスコードの再設定", h("div", { class: "reset-card" }, body), { back: "#/auth?login" }));
    step1();
  });

  // ---------- 登録 / ログイン ----------
  function field(label, input, hint) {
    return h("label", { class: "field" }, h("span", { class: "field-label" }, label), input, hint || null);
  }
  const digits = (el) => el.addEventListener("input", () => { el.value = el.value.replace(/\D/g, "").slice(0, 4); });

  SD.route("/auth", () => {
    if (SD.me) return SD.go("#/social");
    const wantLogin = location.hash.includes("login");
    let mode = wantLogin ? "login" : (() => { try { return localStorage.getItem("sd_mode") || "register"; } catch { return "register"; } })();
    const card = h("div", { class: "auth-card" });
    const wrap = h("div", { class: "auth" },
      h("a", { class: "auth-back", href: "#/" }, SD.icon("back", 18), h("span", null, "ホームへ")),
      h("div", { class: "auth-logo" }, SD.wordmarkSmall()),
      card);
    SD.mount(wrap);
    const setMode = (m) => {
      mode = m;
      try { localStorage.setItem("sd_mode", m); } catch {}
      draw();
    };
    const tabs = () =>
      h("div", { class: "seg", role: "tablist" },
        ["register", "login"].map((m) =>
          h("button", { role: "tab", "aria-selected": String(mode === m), class: mode === m ? "on" : "", onclick: () => setMode(m) }, m === "register" ? "新規登録" : "ログイン")));

    function draw() {
      card.replaceChildren(tabs(), mode === "register" ? registerForm() : loginForm());
    }

    function loginForm() {
      const name = h("input", { class: "input", autocomplete: "username", maxLength: 20, "aria-label": "ユーザー名" });
      const pass = h("input", { class: "input pass", type: "password", inputMode: "numeric", autocomplete: "current-password", maxLength: 4, placeholder: "••••", "aria-label": "パスコード" });
      digits(pass);
      const err = h("p", { class: "form-err", role: "alert" });
      const btn = h("button", { class: "btn primary block", type: "submit" }, "ログイン");
      const form = h("form", {
        class: "form",
        onsubmit: async (e) => {
          e.preventDefault();
          err.textContent = "";
          btn.disabled = true;
          try {
            const r = await SD.post("/login", { name: name.value, pass: pass.value }, { quiet: true });
            SD.setToken(r.token);
            await SD.enter(r.me, { inbox: true });
          } catch (ex) {
            if (ex.extra?.code === "banned") SD.showBan(ex.extra);
            else { err.textContent = ex.message; pass.value = ""; }
          } finally { btn.disabled = false; }
        },
      }, field("ユーザー名", name), field("パスコード(4桁の数字)", pass), err, btn,
        h("p", { class: "hint center" }, "前回の続きから再開できます。"),
        h("p", { class: "center" }, h("a", { class: "link-btn", href: "#/reset" }, "パスコードをお忘れですか？")));
      setTimeout(() => name.focus(), 30);
      return form;
    }

    function registerForm() {
      const name = h("input", { class: "input", autocomplete: "off", maxLength: 20, placeholder: "好きな名前", "aria-label": "ユーザー名" });
      const pass = h("input", { class: "input pass", type: "password", inputMode: "numeric", autocomplete: "new-password", maxLength: 4, placeholder: "••••", "aria-label": "パスコード" });
      const org = h("input", { class: "input", autocomplete: "off", autocapitalize: "off", spellcheck: false, maxLength: 32, placeholder: "管理者から伝えられたID", "aria-label": "組織ID" });
      digits(pass);
      const nameMsg = h("small", { class: "field-msg", "aria-live": "polite" });
      const err = h("p", { class: "form-err", role: "alert" });
      const check = SD.debounce(async () => {
        const v = name.value.trim();
        nameMsg.className = "field-msg";
        if (!v) return (nameMsg.textContent = "");
        try {
          const r = await SD.get("/check-name?name=" + encodeURIComponent(v), { quiet: true });
          nameMsg.textContent = r.available ? "この名前は使えます" : "この名前は既に使われています";
          nameMsg.classList.add(r.available ? "ok" : "ng");
        } catch {}
      }, 350);
      name.addEventListener("input", check);
      org.addEventListener("input", () => { org.value = org.value.toLowerCase().replace(/[^a-z0-9]/g, ""); });
      const btn = h("button", { class: "btn primary block", type: "submit" }, "次へ");
      const form = h("form", {
        class: "form",
        onsubmit: async (e) => {
          e.preventDefault();
          err.textContent = "";
          if (pass.value.length !== 4) return (err.textContent = "パスコードは4桁の数字で入力してください");
          btn.disabled = true;
          try {
            const r = await SD.post("/register", { name: name.value, pass: pass.value, org: org.value }, { quiet: true });
            SD.setToken(r.token);
            SD.me = r.me;
            iconStep();
          } catch (ex) { err.textContent = ex.message; } finally { btn.disabled = false; }
        },
      }, field("ユーザー名", name, nameMsg), field("パスコード(4桁の数字)", pass), field("組織ID", org), err, btn,
        h("p", { class: "hint center" }, "ユーザー名は自由に決められます。パスコードはログインのときに使います。"));
      setTimeout(() => name.focus(), 30);
      return form;
    }

    function stepDots(n) {
      return h("div", { class: "steps", "aria-label": `手順 ${n}/2` }, [1, 2].map((i) => h("span", { class: i === n ? "on" : i < n ? "done" : "" })));
    }

    function iconStep() {
      const prev = h("div", { class: "icon-prev" });
      const paint = () => prev.replaceChildren(SD.avatar(SD.me, 120));
      paint();
      const pick = h("button", { class: "btn", type: "button", onclick: async () => {
        const id = await SD.pickIcon();
        if (!id) return;
        try { const r = await SD.post("/me/profile", { icon: id }); SD.me = r.me; paint(); next.textContent = "次へ"; } catch (e) { SD.fail(e); }
      } }, "画像を選ぶ");
      const next = h("button", { class: "btn primary block", onclick: bioStep }, "スキップ");
      card.replaceChildren(
        stepDots(1),
        h("h2", { class: "step-title" }, "プロフィール画像"),
        h("p", { class: "hint center" }, "アップロードした画像は丸く切り取られます。あとからプロフィール編集でも変えられます。"),
        prev, h("div", { class: "row center" }, pick), next);
    }

    function bioStep() {
      const ta = h("textarea", { class: "input", rows: 4, maxLength: 200, placeholder: "自己紹介を書いてみましょう", "aria-label": "自己紹介" });
      const cnt = h("small", { class: "counter" }, "0 / 200");
      ta.addEventListener("input", () => (cnt.textContent = `${ta.value.length} / 200`));
      const finish = async (save) => {
        try {
          if (save && ta.value.trim()) { const r = await SD.post("/me/profile", { bio: ta.value.trim() }); SD.me = r.me; }
        } catch (e) { return SD.fail(e); }
        await SD.enter(SD.me, { inbox: false });
      };
      card.replaceChildren(
        stepDots(2),
        h("h2", { class: "step-title" }, "自己紹介"),
        h("p", { class: "hint center" }, "200文字までです。書かずにスキップしてもかまいません。"),
        ta, cnt,
        h("button", { class: "btn primary block", onclick: () => finish(true) }, "はじめる"),
        h("button", { class: "btn ghost block", onclick: () => finish(false) }, "スキップ"));
    }

    draw();
  });

  // ---------- プロフィール編集 ----------
  SD.route("/profile", async () => {
    if (!SD.need()) return;
    const me = SD.me;
    let icon = me.icon, removed = false;
    const prev = h("div", { class: "icon-prev" });
    const paint = () => prev.replaceChildren(SD.avatar({ icon }, 120));
    paint();
    const name = h("input", { class: "input", value: me.name, maxLength: 20, "aria-label": "名前" });
    const bio = h("textarea", { class: "input", rows: 5, maxLength: 200, "aria-label": "自己紹介" }, me.bio || "");
    const cnt = h("small", { class: "counter" }, `${(me.bio || "").length} / 200`);
    bio.addEventListener("input", () => (cnt.textContent = `${bio.value.length} / 200`));
    const err = h("p", { class: "form-err", role: "alert" });
    const reset = h("button", { class: "btn ghost", hidden: !icon, onclick: () => { icon = null; removed = true; reset.hidden = true; paint(); } }, "初期アイコンに戻す");
    const change = h("button", { class: "btn", onclick: async () => { const id = await SD.pickIcon(); if (id) { icon = id; removed = false; reset.hidden = false; paint(); } } }, "画像を変更");
    const save = h("button", { class: "btn primary block", onclick: async () => {
      err.textContent = "";
      save.disabled = true;
      try {
        const patch = { name: name.value, bio: bio.value };
        if (icon !== me.icon || removed) patch.icon = icon;
        const r = await SD.post("/me/profile", patch, { quiet: false });
        SD.me = r.me;
        SD.toast("プロフィールを保存しました");
        SD.render();
      } catch (e) { err.textContent = e.message; } finally { save.disabled = false; }
    } }, "保存する");
    SD.mount(SD.shell("プロフィール編集",
      h("div", { class: "profile-edit" },
        prev, h("div", { class: "row center wrap" }, change, reset),
        field("名前", name), field("自己紹介", bio, cnt), err, save,
        h("div", { class: "my-id" },
          h("span", { class: "field-label" }, "あなたのユーザーID(パスコードの再設定で使います)"),
          h("code", { class: "my-id-code" }, me.id),
          h("button", { class: "btn small", type: "button", onclick: async () => {
            try { await navigator.clipboard.writeText(me.id); SD.toast("IDをコピーしました"); } catch { SD.toast("コピーできませんでした。手で選んでください", { error: true }); }
          } }, "コピー")),
        h("p", { class: "hint center" }, `所属: ${me.orgName}`))));
  });
})();
