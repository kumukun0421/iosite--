// アプリ外枠(ヘッダー・左メニュー)、ポーリング、利用制限画面、起動処理
(function () {
  const SD = window.SD;
  const h = SD.h;

  // ---------- 左メニュー付きの画面枠 ----------
  SD.shell = function (title, content, opt = {}) {
    const drawer = SD.me ? buildDrawer() : h("div", { class: "drawer-wrap" });
    const open = () => { drawer.classList.add("open"); document.body.classList.add("noscroll"); drawer.querySelector("button, a")?.focus(); };
    const close = () => { drawer.classList.remove("open"); document.body.classList.remove("noscroll"); };
    drawer.addEventListener("click", (e) => { if (e.target === drawer) close(); });
    drawer.addEventListener("click", (e) => { if (e.target.closest("[data-nav]")) close(); });
    const dot = h("span", { class: "dot", hidden: SD.unread <= 0 });
    SD.onUnread = () => { dot.hidden = SD.unread <= 0; const b = drawer.querySelector(".nav-badge"); if (b) { b.hidden = SD.unread <= 0; b.textContent = String(SD.unread); } };
    const left = opt.back || !SD.me
      ? h("button", { class: "icon-btn", "aria-label": "戻る", onclick: () => (typeof opt.back === "string" ? SD.go(opt.back) : history.back()) }, SD.icon("back", 22))
      : h("button", { class: "icon-btn menu-btn", "aria-label": "メニューを開く", onclick: open }, SD.icon("menu", 24), dot);
    const keyClose = (e) => { if (e.key === "Escape") close(); };
    document.addEventListener("keydown", keyClose);
    SD.onCleanup(() => { document.removeEventListener("keydown", keyClose); document.body.classList.remove("noscroll"); });
    const head = h("header", { class: "topbar" }, left, h("h1", { class: "top-title" }, title), h("span", { class: "top-spacer" }, opt.right || null));
    const main = h("main", { class: "page" + (opt.wide ? " wide" : "") + (opt.flush ? " flush" : "") }, content);
    const parts = [head, main, drawer];
    if (opt.fab) parts.push(opt.fab);
    return h("div", { class: "shell" }, parts);
  };

  function buildDrawer() {
    const cur = location.hash.split("/")[1] || "";
    const item = (hash, icon, label, key, extra) =>
      h("a", { href: hash, "data-nav": "1", class: "nav-item" + (cur === key ? " cur" : ""), "aria-current": cur === key ? "page" : null }, SD.icon(icon, 20), h("span", null, label), extra);
    const badge = h("span", { class: "nav-badge", hidden: SD.unread <= 0 }, String(SD.unread));
    const notifBtn =
      "Notification" in window && Notification.permission === "default"
        ? h("button", { class: "nav-item", onclick: async () => { const r = await Notification.requestPermission(); SD.toast(r === "granted" ? "通知をオンにしました" : "通知は許可されませんでした"); SD.render(); } }, SD.icon("bell", 20), h("span", null, "通知をオンにする"))
        : null;
    return h("div", { class: "drawer-wrap" },
      h("nav", { class: "drawer", "aria-label": "メインメニュー" },
        h("div", { class: "drawer-top" },
          SD.wordmarkSmall(),
          h("button", { class: "icon-btn", "aria-label": "メニューを閉じる", onclick: (e) => e.currentTarget.closest(".drawer-wrap").classList.remove("open") || document.body.classList.remove("noscroll") }, SD.icon("close", 22))),
        h("a", { href: "#/profile", "data-nav": "1", class: "me-card" }, SD.avatar(SD.me, 44), h("div", null, h("b", null, SD.me.name), h("small", null, SD.me.orgName))),
        h("div", { class: "nav-list" },
          item("#/social", "bell", "Social", "social"),
          item("#/direct", "chat", "Direct", "direct", badge),
          item("#/calendar", "cal", "SocialCalendar", "calendar"),
          item("#/profile", "user", "プロフィール編集", "profile"),
          item("#/settings", "gear", "設定", "settings"),
          notifBtn),
        h("div", { class: "nav-bottom" },
          h("button", { class: "nav-item", onclick: () => SD.logout() }, SD.icon("out", 20), h("span", null, "ログアウト")),
          h("button", { class: "nav-item admin", onclick: () => SD.adminGate() }, SD.icon("shield", 20), h("span", null, "管理者専用")))));
  }

  SD.wordmarkSmall = () => h("span", { class: "wm-small" }, h("span", { class: "o" }, "Social"), h("span", null, "Direct"));

  // ---------- ログアウト / セッション切れ ----------
  SD.logout = async () => {
    await SD.unsubscribePush();
    SD.setToken(null);
    SD.me = null;
    SD.adminToken = null;
    SD.stopPoll();
    SD.go("#/");
  };
  SD.sessionLost = (code) => {
    if (!SD.me && !SD.token()) return;
    SD.setToken(null);
    SD.me = null;
    SD.stopPoll();
    SD.toast(code === "gone" ? "このアカウントは削除されました" : "ログインの有効期限が切れました。もう一度ログインしてください", { error: true });
    SD.go("#/auth");
  };

  // ---------- 利用制限(ペナルティ)画面 ----------
  let banEl = null, banTimer = null;
  SD.showBan = function ({ until, reason }) {
    if (banEl) return;
    SD.stopPoll();
    SD.closeAllModals();
    const count = h("div", { class: "ban-count", "aria-live": "off" });
    const sub = h("div", { class: "ban-sub" });
    const btn = h("button", { class: "btn primary", hidden: true, onclick: () => { clear(); SD.setToken(null); SD.me = null; SD.go("#/auth"); } }, "ログイン画面へ");
    const clear = () => { clearInterval(banTimer); banEl?.remove(); banEl = null; };
    // 制限中でも、トップページに戻れるようにする(この端末のログインは外す)
    const top = h("button", { class: "btn ghost", onclick: () => { clear(); SD.setToken(null); SD.me = null; SD.go("#/"); } }, "トップページへ");
    const tick = () => {
      const s = Math.max(0, Math.ceil((until - Date.now()) / 1000));
      count.textContent = `あと ${s} 秒`;
      const d = Math.floor(s / 86400), hh = Math.floor((s % 86400) / 3600), m = Math.floor((s % 3600) / 60);
      sub.textContent = s > 0 ? `約 ${d ? d + "日 " : ""}${hh}時間 ${m}分` + ` ・ 解除 ${new Date(until).toLocaleString("ja-JP")}` : "制限は解除されました";
      if (s <= 0) { clearInterval(banTimer); btn.hidden = false; count.textContent = "解除されました"; }
    };
    banEl = h("div", { class: "ban", role: "alertdialog", "aria-modal": "true", "aria-label": "ログインが制限されています" },
      h("div", { class: "ban-card" },
        h("div", { class: "ban-mark" }, SD.icon("shield", 34)),
        h("h2", null, "ログインが制限されています"),
        h("p", { class: "ban-reason" }, h("small", null, "理由"), reason || "管理者による制限"),
        count, sub, btn, top));
    document.body.append(banEl);
    tick();
    banTimer = setInterval(tick, 1000);
  };

  // ---------- 定期チェック(通知・新着の件数) ----------
  let pollTimer = null, since = 0;
  SD.stopPoll = () => { clearInterval(pollTimer); pollTimer = null; };
  SD.startPoll = () => {
    SD.stopPoll();
    since = Date.now();
    const run = async () => {
      if (!SD.me || document.hidden) return;
      try {
        const r = await SD.get("/poll?since=" + since, { quiet: false });
        since = r.now;
        SD.unread = r.unread;
        SD.onUnread && SD.onUnread();
        const fresh = [
          ...r.notices.map((n) => ({ title: n.system ? "運営からのお知らせ" : `${n.from}さんからお知らせ`, body: n.text, hash: "#/social" })),
          ...r.dms.map((d) => ({ title: `${d.from}さんからメッセージ`, body: d.text, hash: "#/direct/" + encodeURIComponent(d.chatId) })),
        ];
        for (const f of fresh.slice(0, 3)) {
          const onChat = location.hash === f.hash;
          if (onChat) continue;
          SD.toast(`${f.title}`, { action: { label: "開く", fn: () => SD.go(f.hash) }, ms: 7000 });
        }
        if (fresh.length && location.hash === "#/social") window.dispatchEvent(new Event("sd-new-content"));
      } catch {}
    };
    pollTimer = setInterval(run, 60000);
    document.addEventListener("visibilitychange", () => { if (!document.hidden && SD.me) run(); });
  };

  // ---------- ログイン後の入口 ----------
  SD.enter = async function (me, { inbox = true } = {}) {
    SD.me = me;
    SD.startPoll();
    SD.refreshUnread();
    let items = [];
    if (inbox) {
      try { items = (await SD.get("/inbox")).items; } catch (e) { SD.fail(e); }
    }
    SD.go("#/social");
    // 通知を聞くのは一度だけ。そのあとで受信箱を出す
    SD.afterRender(() => SD.askNotify(() => { if (items.length) SD.inboxModal(items); }));
  };

  // 未読数を、サーバーの数に合わせる(Directの新着も含む)
  SD.refreshUnread = async () => {
    if (!SD.me) return;
    try { const r = await SD.get("/unread"); SD.unread = r.count; SD.onUnread && SD.onUnread(); } catch {}
  };

  SD.inboxModal = function (items) {
    const ids = items.map((i) => i.id);
    const mark = (only) => SD.post("/inbox/read", { ids: only || ids }).catch(() => {});
    const label = (t) => (t === "dm" ? "Direct" : t === "update" ? "アップデート" : "お知らせ");
    const showEntries = (i) => SD.modal({
      title: i.from, wide: true,
      body: h("div", { class: "inbox" }, ...(i.entries || []).map((e) => h("div", { class: "upd-entry" }, h("b", null, e.title), h("p", null, e.body)))),
      actions: [{ label: "閉じる", primary: true, fn: () => {} }],
    });
    const showRich = (i) => SD.modal({
      title: i.from, wide: true,
      body: h("div", { class: "inbox" }, h("p", null, ...SD.richText(i.text))),
      actions: [{ label: "閉じる", primary: true, fn: () => {} }],
    });
    const open = (i) => {
      mark([i.id]);
      SD.closeAllModals();
      if (i.type === "update") return showEntries(i);
      if (i.rich) return showRich(i);
      if (i.link) SD.go(i.link.hash);
    };
    const body = h("div", { class: "inbox" },
      h("p", { class: "inbox-lead" }, `前回から ${items.length}件 届いています`),
      h("ul", { class: "inbox-list" }, items.map((i) =>
        h("li", { class: "inbox-item tap " + i.type, role: "button", tabindex: "0", onclick: () => open(i),
          onkeydown: (e) => { if (e.key === "Enter") open(i); } },
          h("div", { class: "inbox-ic" }, SD.icon(i.type === "dm" ? "chat" : "bell", 18)),
          h("div", { class: "inbox-tx" },
            h("div", { class: "inbox-top" }, h("b", null, i.from), h("span", { class: "time" }, SD.fmtTime(i.at)), h("span", { class: "badge" }, label(i.type))),
            h("p", null, ...(i.rich ? SD.richText(i.text) : [i.text])))))));
    SD.modal({
      title: "届いたお知らせ", body, wide: true, onClose: () => mark(),
      actions: [{ label: "次へ", primary: true, fn: () => {} }],
    });
  };

  // ---------- 管理者専用の入口(パスワード入力) ----------
  SD.adminGate = function () {
    const input = h("input", { type: "password", class: "input", autocomplete: "off", spellcheck: false, placeholder: "管理者パスワード", "aria-label": "管理者パスワード", autofocus: true });
    const err = h("p", { class: "form-err", role: "alert" });
    const submit = async (close, btn) => {
      err.textContent = "";
      try {
        const r = await SD.post("/admin/login", { password: input.value }, { quiet: true });
        SD.adminToken = r.token;
        close();
        SD.go("#/admin");
      } catch (e) { err.textContent = e.message; input.select(); return false; }
    };
    input.addEventListener("keydown", (e) => { if (e.key === "Enter") document.querySelector(".modal-foot .btn.primary")?.click(); });
    SD.modal({ title: "管理者専用", body: h("div", null, h("p", { class: "hint" }, "管理者用パスワードを入力してください。"), input, err), actions: [{ label: "キャンセル", ghost: true }, { label: "開く", primary: true, fn: submit }] });
  };

  // ---------- 起動 ----------
  SD.boot = async function () {
    window.addEventListener("hashchange", () => SD.render());
    if (SD.token()) {
      try {
        const r = await SD.post("/resume", {}, { quiet: true });
        SD.me = r.me;
        SD.startPoll();
        SD.refreshUnread();
        SD.registerPush();
        const inbox = await SD.get("/inbox").catch(() => ({ items: [] }));
        if (inbox.items.length) SD.afterRender(() => SD.inboxModal(inbox.items));
        const hash = location.hash;
        if (!hash || hash === "#/" || hash === "#/auth") {
          SD.go("#/social");
          return;
        }
      } catch (e) {
        if (e.extra?.code === "banned") { SD.showBan(e.extra); return; }
        if (e.status === 401) SD.setToken(null);
      }
    }
    SD.render();
  };
})();
