// Social(つぶやき・お知らせの流れ)、投稿作成、コメント画面
(function () {
  const SD = window.SD;
  const h = SD.h;

  // ---------- 投稿の作成 ----------
  function composeModal({ kind, recipients, onDone }) {
    const notice = kind === "notice";
    const max = notice ? 20000 : 2000;
    const ta = h("textarea", { class: "input compose-text", rows: 7, maxLength: max, placeholder: notice ? "お知らせの内容を書く" : "いまどうしてる?", "aria-label": "本文", autofocus: true });
    const cnt = h("small", { class: "counter" }, `0 / ${max}`);
    ta.addEventListener("input", () => (cnt.textContent = `${ta.value.length} / ${max}`));
    const media = [];
    const strip = h("div", { class: "attach-strip" });
    const busy = h("small", { class: "hint", hidden: true }, "アップロード中…");
    const drawStrip = () =>
      strip.replaceChildren(...media.map((m, i) =>
        h("div", { class: "attach" },
          m.type === "video" ? h("video", { src: m.url, muted: true, preload: "metadata" }) : h("img", { src: m.url, alt: "添付画像" }),
          h("button", { class: "attach-x", "aria-label": "添付を外す", onclick: () => { media.splice(i, 1); drawStrip(); } }, SD.icon("close", 14)))));
    const file = h("input", { type: "file", accept: "image/*,video/mp4,video/webm", multiple: true, hidden: true });
    file.addEventListener("change", async () => {
      const files = [...file.files].slice(0, 4 - media.length);
      file.value = "";
      busy.hidden = false;
      for (const f of files) {
        try {
          const r = await SD.uploadFile(f);
          media.push({ id: r.id, type: r.type, url: URL.createObjectURL(f) });
          drawStrip();
        } catch (e) { SD.fail(e); }
      }
      busy.hidden = true;
    });
    const attachBtn = h("button", { class: "btn small", type: "button", onclick: () => (media.length >= 4 ? SD.toast("添付は4つまでです") : file.click()) }, SD.icon("image", 18), "画像・動画");
    const info = notice
      ? h("div", { class: "to-sum" }, h("small", null, "宛先"), h("span", null, recipients.label))
      : null;
    const body = h("div", { class: "compose" }, info, ta, h("div", { class: "compose-meta" }, attachBtn, busy, cnt), strip, file,
      h("p", { class: "hint" }, "画像は1つ2MBまで(自動で縮小します)。動画は1つ5MBまで(mp4/webm)。"));
    SD.modal({
      title: notice ? "お知らせを書く" : "つぶやく", body, wide: true,
      actions: [
        { label: "キャンセル", ghost: true },
        {
          label: notice ? "お知らせする" : "投稿する", primary: true,
          fn: async () => {
            if (!ta.value.trim()) { SD.toast("本文を入力してください", { error: true }); return false; }
            try {
              await SD.post("/posts", { kind, text: ta.value, media: media.map((m) => ({ id: m.id, type: m.type })), toUsers: recipients?.users, toTags: recipients?.tags });
              SD.toast(notice ? "お知らせしました" : "投稿しました");
              onDone && onDone();
            } catch (e) { SD.fail(e); return false; }
          },
        },
      ],
    });
  }

  async function recipientStep(onDone) {
    let info;
    try { info = await SD.get("/users"); } catch (e) { return SD.fail(e); }
    const users = info.users.filter((u) => u.id !== SD.me.id);
    if (!users.length) return SD.toast("同じ組織に宛先にできる人がまだいません", { error: true });
    const pk = SD.picker({ users, tags: info.tags });
    SD.modal({
      title: "誰にお知らせしますか", body: pk.el, wide: true,
      actions: [
        { label: "キャンセル", ghost: true },
        {
          label: "次へ", primary: true,
          fn: () => {
            if (!pk.users.length && !pk.tags.length) { SD.toast("宛先を1つ以上選んでください", { error: true }); return false; }
            const names = pk.users.map((id) => users.find((u) => u.id === id)?.name).filter(Boolean);
            const tnames = pk.tags.map((id) => "#" + info.tags.find((t) => t.id === id)?.name);
            const all = [...tnames, ...names];
            const label = all.slice(0, 5).join("、") + (all.length > 5 ? ` ほか${all.length - 5}件` : "");
            setTimeout(() => composeModal({ kind: "notice", recipients: { users: pk.users, tags: pk.tags, label }, onDone }), 0);
          },
        },
      ],
    });
  }

  function chooseKind(onDone) {
    const opt = (title, desc, icon, fn) =>
      h("button", { class: "choice", onclick: () => { SD.closeAllModals(); fn(); } }, SD.icon(icon, 26), h("div", null, h("b", null, title), h("small", null, desc)));
    SD.modal({
      title: "何を投稿しますか", body: h("div", { class: "choices" },
        opt("投稿", "日々のつぶやきを、同じ組織のみんなに見せます", "edit", () => composeModal({ kind: "post", onDone })),
        opt("お知らせ", "選んだ人だけに、メッセージや画像・動画を届けます", "bell", () => recipientStep(onDone))),
    });
  }

  // ---------- Social ----------
  SD.route("/social", async () => {
    if (!SD.need()) return;
    const list = h("div", { class: "feed" });
    const sentinel = h("div", { class: "sentinel" });
    const endNote = h("p", { class: "feed-end", hidden: true }, "ここまでです");
    const fresh = h("button", { class: "fresh-pill", hidden: true, onclick: () => SD.render() }, "新しい投稿があります。タップして更新");
    let next = null, loading = false, done = false, count = 0;
    async function more() {
      if (loading || done) return;
      loading = true;
      try {
        const r = await SD.get("/feed" + (next ? "?cursor=" + encodeURIComponent(next) : ""));
        r.items.forEach((p) => list.append(SD.postCard(p)));
        count += r.items.length;
        next = r.next;
        if (!next) {
          done = true;
          if (!count) list.append(h("div", { class: "empty-big" }, h("b", null, "まだ何もありません"), h("p", null, "右下のボタンから、最初の投稿をしてみましょう。")));
          else endNote.hidden = false;
        }
      } catch (e) { SD.fail(e); } finally { loading = false; }
      if (!done && sentinel.getBoundingClientRect().top < window.innerHeight + 400) more();
    }
    const io = new IntersectionObserver((en) => en.some((e) => e.isIntersecting) && more(), { rootMargin: "500px" });
    const onNew = () => (fresh.hidden = false);
    window.addEventListener("sd-new-content", onNew);
    SD.onCleanup(() => { io.disconnect(); window.removeEventListener("sd-new-content", onNew); });
    const fab = h("button", { class: "fab", "aria-label": "投稿する", onclick: () => chooseKind(() => SD.render()) }, SD.icon("plus", 22), h("span", null, "投稿"));
    SD.mount(SD.shell("Social", [fresh, list, sentinel, endNote], {
      fab,
      right: h("button", { class: "icon-btn", "aria-label": "更新", onclick: () => SD.render() }, SD.icon("refresh", 20)),
    }));
    io.observe(sentinel);
    more();
  });

  // ---------- コメント画面 ----------
  SD.route("/post/:id", async ({ id }) => {
    if (!SD.need()) return;
    let r;
    try { r = await SD.get("/posts/" + encodeURIComponent(id)); } catch (e) { SD.fail(e); return SD.go("#/social"); }
    const cm = SD.comments({
      load: () => SD.get(`/posts/${encodeURIComponent(id)}/comments`),
      send: (text, parent) => SD.post(`/posts/${encodeURIComponent(id)}/comments`, { text, parent }),
    });
    SD.mount(SD.shell("コメント", h("div", { class: "detail" }, SD.postCard(r.post, { detail: true }), h("h3", { class: "sec-title" }, "コメント"), cm.el), { back: "#/social" }));
  });
})();
