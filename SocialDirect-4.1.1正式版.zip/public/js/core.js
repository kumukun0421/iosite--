// SocialDirect 共通部品: DOM生成・API・ルーター・モーダル
(function () {
  const SD = (window.SD = { me: null, adminToken: null, cleanups: [], unread: 0 });

  // ---------- DOM ----------
  SD.h = function h(tag, props, ...kids) {
    const el = document.createElement(tag);
    if (props) {
      for (const [k, v] of Object.entries(props)) {
        if (v === undefined || v === null || v === false) continue;
        if (k === "class") el.className = v;
        else if (k === "style" && typeof v === "object") Object.assign(el.style, v);
        else if (k.startsWith("on") && typeof v === "function") el.addEventListener(k.slice(2).toLowerCase(), v);
        else if (k === "html") throw new Error("html is not allowed");
        else if (k in el && k !== "list" && k !== "type" && k !== "form") el[k] = v;
        else el.setAttribute(k, v === true ? "" : v);
      }
    }
    const add = (c) => {
      if (c === null || c === undefined || c === false) return;
      if (Array.isArray(c)) return c.forEach(add);
      el.append(c instanceof Node ? c : document.createTextNode(String(c)));
    };
    kids.forEach(add);
    return el;
  };
  const h = SD.h;
  // replaceChildren 用: 配列を平らにし、null/false を除く
  SD.kids = (...items) => items.flat(Infinity).filter((x) => x !== null && x !== undefined && x !== false);
  SD.svg = function (path, { size = 22, fill = false, cls = "" } = {}) {
    const ns = "http://www.w3.org/2000/svg";
    const s = document.createElementNS(ns, "svg");
    s.setAttribute("viewBox", "0 0 24 24");
    s.setAttribute("width", size);
    s.setAttribute("height", size);
    s.setAttribute("aria-hidden", "true");
    if (cls) s.setAttribute("class", cls);
    s.setAttribute("fill", fill ? "currentColor" : "none");
    s.setAttribute("stroke", fill ? "none" : "currentColor");
    s.setAttribute("stroke-width", "1.9");
    s.setAttribute("stroke-linecap", "round");
    s.setAttribute("stroke-linejoin", "round");
    const p = document.createElementNS(ns, "path");
    p.setAttribute("d", path);
    s.append(p);
    return s;
  };
  SD.icons = {
    menu: "M4 7h16M4 12h16M4 17h16",
    gear: "M12 9a3 3 0 100 6 3 3 0 000-6zM4 12h2M18 12h2M12 4v2M12 18v2M6.4 6.4l1.4 1.4M16.2 16.2l1.4 1.4M6.4 17.6l1.4-1.4M16.2 7.8l1.4-1.4",
    close: "M6 6l12 12M18 6L6 18",
    plus: "M12 5v14M5 12h14",
    good: "M7 11v9H4v-9h3zm0 0l4-8c1.6 0 2.5 1.2 2.2 2.7L12.6 9H19a2 2 0 0 1 2 2.4l-1.4 7A2 2 0 0 1 17.6 20H7",
    comment: "M5 5h14a1 1 0 0 1 1 1v9a1 1 0 0 1-1 1H10l-4 3.5V16H5a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1z",
    back: "M15 5l-7 7 7 7",
    send: "M4 12L20 4l-5 16-3.5-6.5L4 12zM11.5 13.5L20 4",
    search: "M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14zM20 20l-4-4",
    image: "M4 5h16v14H4zM4 16l5-5 4 4 3-3 4 4M9 9.5h.01",
    trash: "M5 7h14M10 7V4h4v3M7 7l1 13h8l1-13",
    edit: "M4 20h4L19 9l-4-4L4 16v4zM13.5 6.5l4 4",
    cal: "M5 6h14v14H5zM5 10h14M9 3v4M15 3v4",
    chat: "M4 5h16v11H9l-5 4V5z",
    bell: "M6 17V11a6 6 0 0 1 12 0v6l1.5 2h-15L6 17zM10 21h4",
    user: "M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM4 21c0-4 3.6-6 8-6s8 2 8 6",
    shield: "M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6l8-3z",
    out: "M10 5H5v14h5M15 8l4 4-4 4M19 12H9",
    flag: "M6 21V4M6 5h11l-2 4 2 4H6",
    check: "M5 12.5l4.5 4.5L19 7.5",
    left: "M14 6l-6 6 6 6",
    refresh: "M20 11a8 8 0 1 0-2.3 5.7M20 4v7h-7",
    right: "M10 6l6 6-6 6",
  };
  SD.icon = (name, size) => SD.svg(SD.icons[name], { size });

  // ---------- 時刻 ----------
  const p2 = (n) => String(n).padStart(2, "0");
  SD.fmtTime = function (ts) {
    const d = new Date(ts), n = new Date();
    const diff = (n - d) / 1000;
    if (diff < 60) return "たった今";
    if (diff < 3600) return `${Math.floor(diff / 60)}分前`;
    const same = d.toDateString() === n.toDateString();
    if (same) return `${p2(d.getHours())}:${p2(d.getMinutes())}`;
    const y = new Date(n - 86400000);
    if (d.toDateString() === y.toDateString()) return `昨日 ${p2(d.getHours())}:${p2(d.getMinutes())}`;
    const yr = d.getFullYear() === n.getFullYear() ? "" : `${d.getFullYear()}/`;
    return `${yr}${d.getMonth() + 1}/${d.getDate()} ${p2(d.getHours())}:${p2(d.getMinutes())}`;
  };
  SD.fmtDT = (s) => {
    const [d, t] = s.split("T");
    const [y, m, dd] = d.split("-");
    return `${+m}/${+dd} ${t}`;
  };
  SD.p2 = p2;

  // ---------- API ----------
  class ApiError extends Error {
    constructor(status, msg, extra) {
      super(msg);
      this.status = status;
      this.extra = extra || {};
    }
  }
  SD.ApiError = ApiError;
  SD.token = () => {
    try { return localStorage.getItem("sd_token"); } catch { return null; }
  };
  SD.setToken = (t) => {
    try { t ? localStorage.setItem("sd_token", t) : localStorage.removeItem("sd_token"); } catch {}
  };
  SD.api = async function (method, path, body, opts = {}) {
    const headers = {};
    if (body !== undefined) headers["content-type"] = "application/json";
    if (opts.admin) headers["x-admin"] = SD.adminToken || "";
    else if (SD.token()) headers.authorization = "Bearer " + SD.token();
    let res;
    try {
      res = await fetch("/api" + path, { method, headers, body: body !== undefined ? JSON.stringify(body) : undefined });
    } catch {
      throw new ApiError(0, "通信できませんでした。ネットワークを確認してください");
    }
    let data = {};
    try { data = await res.json(); } catch {}
    if (!res.ok) {
      const err = new ApiError(res.status, data.error || "エラーが発生しました", data);
      if (!opts.quiet) {
        if (data.code === "banned" && !opts.admin) SD.showBan(data);
        else if ((data.code === "auth" || data.code === "gone") && !opts.admin) SD.sessionLost(data.code);
        else if (data.code === "admin" && opts.admin) { SD.adminToken = null; SD.go("#/social"); SD.toast("管理者の認証が切れました。もう一度入力してください"); }
      }
      throw err;
    }
    return data;
  };
  SD.get = (p, o) => SD.api("GET", p, undefined, o);
  SD.post = (p, b, o) => SD.api("POST", p, b ?? {}, o);
  SD.put = (p, b, o) => SD.api("PUT", p, b ?? {}, o);
  SD.del = (p, o) => SD.api("DELETE", p, undefined, o);
  SD.aget = (p) => SD.api("GET", p, undefined, { admin: true });
  SD.apost = (p, b) => SD.api("POST", p, b ?? {}, { admin: true });
  SD.aput = (p, b) => SD.api("PUT", p, b ?? {}, { admin: true });
  SD.adel = (p) => SD.api("DELETE", p, undefined, { admin: true });

  // ---------- 画面切り替え ----------
  const routes = [];
  SD.route = (pattern, fn) => {
    const keys = [];
    const re = new RegExp("^" + pattern.replace(/:([a-z]+)/gi, (_, k) => (keys.push(k), "([^/]+)")) + "$");
    routes.push({ re, keys, fn });
  };
  SD.go = (hash) => {
    if (location.hash === hash) SD.render();
    else location.hash = hash;
  };
  SD.onCleanup = (fn) => SD.cleanups.push(fn);
  SD.root = () => document.getElementById("app");
  SD.mount = (el) => {
    const r = SD.root();
    r.replaceChildren(el);
    window.scrollTo(0, 0);
  };
  SD.after = [];
  SD.afterRender = (fn) => SD.after.push(fn);
  SD.render = async function () {
    SD.cleanups.splice(0).forEach((f) => { try { f(); } catch {} });
    SD.closeAllModals();
    try {
      await SD.renderInner();
    } finally {
      SD.after.splice(0).forEach((f) => { try { f(); } catch (e) { console.error(e); } });
    }
  };
  SD.renderInner = async function () {
    const path = location.hash.replace(/^#/, "").split("?")[0] || "/";
    for (const r of routes) {
      const m = r.re.exec(path);
      if (m) {
        const params = {};
        r.keys.forEach((k, i) => (params[k] = decodeURIComponent(m[i + 1])));
        try {
          await r.fn(params);
        } catch (e) {
          if (!(e instanceof ApiError)) console.error(e);
          else if (e.status === 0 || e.status >= 500) SD.mount(SD.errorView(e.message));
        }
        return;
      }
    }
    SD.go("#/");
  };
  SD.errorView = (msg) =>
    h("div", { class: "center-msg" }, h("p", null, msg), h("button", { class: "btn", onclick: () => SD.render() }, "もう一度読み込む"));

  // ---------- トースト ----------
  SD.toast = function (msg, opt = {}) {
    let box = document.getElementById("toasts");
    if (!box) {
      box = h("div", { id: "toasts", role: "status", "aria-live": "polite" });
      document.body.append(box);
    }
    const t = h("div", { class: "toast" + (opt.error ? " err" : "") }, h("span", null, msg));
    const kill = () => t.remove();
    if (opt.action) {
      t.append(h("button", { class: "toast-act", onclick: () => { kill(); opt.action.fn(); } }, opt.action.label));
    }
    box.append(t);
    setTimeout(kill, opt.ms || (opt.action ? 12000 : 3600));
    return kill;
  };
  SD.fail = (e) => {
    if (e instanceof ApiError && ["banned", "auth", "gone", "admin"].includes(e.extra.code)) return;
    SD.toast(e.message || "エラーが発生しました", { error: true });
  };

  // ---------- モーダル ----------
  const modals = [];
  SD.closeAllModals = () => {
    while (modals.length) modals.pop().remove();
    document.body.classList.remove("noscroll");
  };
  SD.modal = function ({ title, body, actions = [], wide = false, bare = false, onClose, dismissable = true }) {
    const close = () => {
      const i = modals.indexOf(wrap);
      if (i >= 0) modals.splice(i, 1);
      wrap.remove();
      if (!modals.length) document.body.classList.remove("noscroll");
      onClose && onClose();
    };
    const head = bare ? null : h("div", { class: "modal-head" }, h("h2", null, title || ""), dismissable && h("button", { class: "icon-btn", "aria-label": "閉じる", onclick: close }, SD.icon("close", 20)));
    const foot = actions.length
      ? h("div", { class: "modal-foot" }, actions.map((a) => h("button", {
          class: "btn " + (a.primary ? "primary " : "") + (a.danger ? "danger " : "") + (a.ghost ? "ghost" : ""),
          disabled: !!a.disabled,
          onclick: async (ev) => {
            const b = ev.currentTarget;
            if (a.keep) return a.fn && a.fn(close, b);
            b.disabled = true;
            try { const r = a.fn ? await a.fn(close, b) : undefined; if (r !== false && !a.stay) close(); } finally { b.disabled = false; }
          },
        }, a.label)))
      : null;
    const wrap = h("div", { class: "modal-wrap", onmousedown: (e) => { if (dismissable && e.target === wrap) close(); } },
      h("div", { class: "modal" + (wide ? " wide" : "") + (bare ? " bare" : ""), role: "dialog", "aria-modal": "true", "aria-label": title || "" },
        head, h("div", { class: "modal-body" }, body), foot));
    document.body.append(wrap);
    document.body.classList.add("noscroll");
    modals.push(wrap);
    const f = wrap.querySelector("[autofocus], input, textarea");
    if (f && !bare) setTimeout(() => f.focus({ preventScroll: true }), 30);
    return { close, el: wrap };
  };
  SD.confirm = (msg, okLabel = "OK", danger = false) =>
    new Promise((res) => {
      let done = false;
      SD.modal({
        title: "確認",
        body: h("p", { class: "confirm-msg" }, msg),
        actions: [
          { label: "キャンセル", ghost: true, fn: () => { done = true; res(false); } },
          { label: okLabel, primary: !danger, danger, fn: () => { done = true; res(true); } },
        ],
        onClose: () => { if (!done) res(false); },
      });
    });

  // ---------- アップロード ----------
  const readB64 = (blob) =>
    new Promise((res, rej) => {
      const r = new FileReader();
      r.onload = () => res(String(r.result).split(",")[1] || "");
      r.onerror = rej;
      r.readAsDataURL(blob);
    });
  SD.readB64 = readB64;
  async function resizeImage(file, max = 1600, q = 0.85) {
    const bmp = await createImageBitmap(file);
    const k = Math.min(1, max / Math.max(bmp.width, bmp.height));
    const c = document.createElement("canvas");
    c.width = Math.round(bmp.width * k);
    c.height = Math.round(bmp.height * k);
    c.getContext("2d").drawImage(bmp, 0, 0, c.width, c.height);
    return new Promise((res) => c.toBlob(res, "image/jpeg", q));
  }
  SD.uploadBlob = async (blob, type) => {
    const r = await SD.post("/media", { type, data: await readB64(blob) });
    return r;
  };
  SD.uploadFile = async function (file) {
    if (file.type.startsWith("video/")) {
      if (!["video/mp4", "video/webm", "video/quicktime"].includes(file.type)) throw new ApiError(0, "動画はmp4またはwebmだけ添付できます");
      if (file.size > 5_000_000) throw new ApiError(0, "動画は1つ5MBまでです");
      return SD.uploadBlob(file, file.type);
    }
    if (!file.type.startsWith("image/")) throw new ApiError(0, "画像か動画を選んでください");
    let blob = file;
    if (!(file.type === "image/gif" && file.size < 2_000_000)) blob = await resizeImage(file);
    return SD.uploadBlob(blob, blob.type || "image/jpeg");
  };

  SD.mediaUrl = (id) => "/api/media/" + encodeURIComponent(id);
  SD.debounce = (fn, ms = 200) => {
    let t;
    return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
  };
  SD.match = (q, ...fields) => {
    if (!q) return true;
    const n = q.normalize("NFKC").toLowerCase().trim();
    return fields.some((f) => String(f ?? "").normalize("NFKC").toLowerCase().includes(n));
  };
})();
