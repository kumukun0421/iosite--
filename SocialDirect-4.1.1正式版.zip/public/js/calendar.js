// SocialCalendar(自分のカレンダー・共有カレンダー)
(function () {
  const SD = window.SD;
  const h = SD.h;
  const p2 = SD.p2;
  const WEEK = ["日", "月", "火", "水", "木", "金", "土"];
  const dayStr = (y, m, d) => `${y}-${p2(m + 1)}-${p2(d)}`;
  const fmtRange = (e) => {
    const [sd, st] = e.start.split("T"), [ed, et] = e.end.split("T");
    const f = (d) => { const [, m, dd] = d.split("-"); return `${+m}/${+dd}`; };
    return sd === ed ? `${f(sd)} ${st}〜${et}` : `${f(sd)} ${st} 〜 ${f(ed)} ${et}`;
  };

  SD.route("/calendar", async () => {
    if (!SD.need()) return;
    const qp = new URLSearchParams(location.hash.split("?")[1] || "");
    let calList;
    try { calList = (await SD.get("/cals")).cals; } catch (e) { return SD.fail(e); }
    let calId = qp.get("c") || "me";
    if (!calList.some((c) => c.id === calId)) calId = "me";
    const cal = calList.find((c) => c.id === calId);
    const personal = calId === "me";
    let events = [];
    try { events = (await SD.get(`/cal/${encodeURIComponent(calId)}/events`)).events; } catch (e) { SD.fail(e); }

    const today = new Date();
    let y = today.getFullYear(), m = today.getMonth();
    let sel = dayStr(today.getFullYear(), today.getMonth(), today.getDate());
    const grid = h("div", { class: "cal-grid", role: "grid" });
    const title = h("h2", { class: "cal-title", "aria-live": "polite" });
    const dayBox = h("div", { class: "day-box" });

    const eventsOn = (ds) => events.filter((e) => e.start.slice(0, 10) <= ds && ds <= e.end.slice(0, 10)).sort((a, b) => a.start.localeCompare(b.start));

    function drawGrid() {
      title.textContent = `${y}年${m + 1}月`;
      const first = new Date(y, m, 1).getDay();
      const days = new Date(y, m + 1, 0).getDate();
      const cells = WEEK.map((w, i) => h("div", { class: "cal-wd" + (i === 0 ? " sun" : i === 6 ? " sat" : ""), role: "columnheader" }, w));
      for (let i = 0; i < first; i++) cells.push(h("div", { class: "cal-cell blank" }));
      for (let d = 1; d <= days; d++) {
        const ds = dayStr(y, m, d);
        const evs = eventsOn(ds);
        const wd = (first + d - 1) % 7;
        cells.push(h("button", {
          class: "cal-cell" + (ds === sel ? " sel" : "") + (ds === dayStr(today.getFullYear(), today.getMonth(), today.getDate()) ? " today" : "") + (wd === 0 ? " sun" : wd === 6 ? " sat" : ""),
          role: "gridcell", "aria-label": `${m + 1}月${d}日 予定${evs.length}件`, "aria-selected": String(ds === sel),
          onclick: () => { sel = ds; drawGrid(); drawDay(); },
        }, h("span", { class: "cal-num" }, String(d)), evs.length ? h("span", { class: "cal-dots" }, evs.slice(0, 3).map(() => h("i")), evs.length > 3 ? h("b", null, "+") : null) : null));
      }
      grid.replaceChildren(...cells);
    }

    function drawDay() {
      const [yy, mm, dd] = sel.split("-");
      const evs = eventsOn(sel);
      dayBox.replaceChildren(
        h("div", { class: "day-head" }, h("h3", null, `${+mm}月${+dd}日(${WEEK[new Date(+yy, +mm - 1, +dd).getDay()]})`), h("button", { class: "btn small primary", onclick: () => eventForm() }, SD.icon("plus", 16), "予定を追加")),
        evs.length
          ? h("ul", { class: "ev-list" }, evs.map((e) =>
              h("li", null, h("button", { class: "ev", onclick: () => eventView(e) },
                h("span", { class: "ev-time" }, e.start.slice(0, 10) === e.end.slice(0, 10) ? `${e.start.slice(11)}〜${e.end.slice(11)}` : "複数日"),
                h("span", { class: "ev-title" }, e.title),
                !personal && h("span", { class: "ev-by" }, e.by.name)))))
          : h("p", { class: "empty" }, "この日の予定はありません"));
    }

    // ---- 予定の追加・編集 ----
    function eventForm(ev) {
      const t = h("input", { class: "input", maxLength: 100, value: ev?.title || "", placeholder: "例: 文化祭の準備", "aria-label": "タイトル", autofocus: true });
      const s = h("input", { class: "input", type: "datetime-local", value: ev?.start || `${sel}T09:00`, "aria-label": "開始" });
      const e = h("input", { class: "input", type: "datetime-local", value: ev?.end || `${sel}T10:00`, "aria-label": "終了" });
      const d = h("textarea", { class: "input", rows: 4, maxLength: 2000, placeholder: "詳細(省略できます)", "aria-label": "詳細" }, ev?.detail || "");
      s.addEventListener("change", () => { if (e.value < s.value) e.value = s.value; });
      const body = h("div", { class: "form" },
        h("label", { class: "field" }, h("span", { class: "field-label" }, "タイトル"), t),
        h("div", { class: "two" },
          h("label", { class: "field" }, h("span", { class: "field-label" }, "開始"), s),
          h("label", { class: "field" }, h("span", { class: "field-label" }, "終了"), e)),
        h("label", { class: "field" }, h("span", { class: "field-label" }, "詳細"), d));
      SD.modal({
        title: ev ? "予定を編集" : "予定を追加", body,
        actions: [
          { label: "キャンセル", ghost: true },
          {
            label: "保存する", primary: true,
            fn: async () => {
              const payload = { title: t.value, start: s.value, end: e.value, detail: d.value };
              try {
                if (ev) await SD.put(`/cal/${encodeURIComponent(calId)}/events/${ev.id}`, payload);
                else await SD.post(`/cal/${encodeURIComponent(calId)}/events`, payload);
                if (payload.start) { sel = payload.start.slice(0, 10); const [a, b] = sel.split("-"); y = +a; m = +b - 1; }
                SD.toast(ev ? "予定を更新しました" : "予定を追加しました");
                SD.afterRender(() => {});
                await reload();
              } catch (x) { SD.fail(x); return false; }
            },
          },
        ],
      });
    }

    function eventView(ev) {
      const parts = [
        h("div", { class: "ev-detail" },
          h("p", { class: "ev-range" }, fmtRange(ev)),
          ev.detail ? h("p", { class: "text" }, ev.detail) : h("p", { class: "hint" }, "詳細はありません"),
          !personal && h("p", { class: "hint" }, `作成: ${ev.by.name}`)),
      ];
      if (!personal) {
        const cm = SD.comments({
          load: () => SD.get(`/cal/${encodeURIComponent(calId)}/events/${ev.id}/comments`),
          send: (text, parent) => SD.post(`/cal/${encodeURIComponent(calId)}/events/${ev.id}/comments`, { text, parent }),
        });
        parts.push(h("h3", { class: "sec-title" }, "コメント"), cm.el);
      }
      SD.modal({
        title: ev.title, body: h("div", null, parts), wide: true,
        actions: [
          {
            label: "削除", danger: true, ghost: true,
            fn: async () => {
              if (!(await SD.confirm("この予定を削除しますか?", "削除する", true))) return false;
              try { await SD.del(`/cal/${encodeURIComponent(calId)}/events/${ev.id}`); SD.toast("予定を削除しました"); await reload(); } catch (x) { SD.fail(x); return false; }
            },
          },
          { label: "編集", fn: (close) => { close(); eventForm(ev); }, stay: true },
        ],
      });
    }

    async function reload() {
      try { events = (await SD.get(`/cal/${encodeURIComponent(calId)}/events`)).events; } catch (e) { SD.fail(e); }
      drawGrid();
      drawDay();
    }

    const tabs = h("div", { class: "cal-tabs", role: "tablist" }, calList.map((c) =>
      h("a", { class: "chip" + (c.id === calId ? " on" : ""), role: "tab", "aria-selected": String(c.id === calId), href: "#/calendar" + (c.id === "me" ? "" : "?c=" + encodeURIComponent(c.id)) }, c.name)));
    const nav = (delta) => { m += delta; if (m < 0) { m = 11; y--; } if (m > 11) { m = 0; y++; } drawGrid(); };
    const head = h("div", { class: "cal-head" },
      h("button", { class: "icon-btn", "aria-label": "前の月", onclick: () => nav(-1) }, SD.icon("left", 22)),
      title,
      h("button", { class: "icon-btn", "aria-label": "次の月", onclick: () => nav(1) }, SD.icon("right", 22)),
      h("button", { class: "btn small ghost", onclick: () => { y = today.getFullYear(); m = today.getMonth(); sel = dayStr(y, m, today.getDate()); drawGrid(); drawDay(); } }, "今日"));
    drawGrid();
    drawDay();
    SD.mount(SD.shell("SocialCalendar", h("div", { class: "calendar" }, tabs,
      h("p", { class: "cal-kind" }, personal ? "自分だけが見られるカレンダーです" : `「${cal.name}」の参加者で共有しています`),
      head, grid, dayBox)));
  });
})();
