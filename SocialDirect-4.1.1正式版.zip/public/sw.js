// 通知(Web Push)を受け取って表示する。本文は、サーバーが送った「誰から・何の通知か」だけ。
self.addEventListener("install", () => self.skipWaiting());
self.addEventListener("activate", (e) => e.waitUntil(self.clients.claim()));

self.addEventListener("push", (e) => {
  let d = {};
  try { d = e.data ? e.data.json() : {}; } catch { d = {}; }
  e.waitUntil(self.registration.showNotification(d.title || "SocialDirect", {
    body: d.body || "",
    data: { hash: d.url || "#/social" },
  }));
});

self.addEventListener("notificationclick", (e) => {
  e.notification.close();
  const hash = (e.notification.data && e.notification.data.hash) || "#/social";
  e.waitUntil((async () => {
    const list = await self.clients.matchAll({ type: "window", includeUncontrolled: true });
    const w = list.find((c) => "focus" in c);
    if (w) {
      await w.focus();
      w.postMessage({ type: "go", hash });
      return;
    }
    await self.clients.openWindow(self.location.origin + "/" + hash);
  })());
});
